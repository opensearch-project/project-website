# Synthetic OpenSearch history lab

The source and synthetic queries were executed on 10 October 2026 GST. The public documentation and package metadata were updated on 12 October 2026 GST without a new runtime run. Executable source, fixtures, mappings, queries and image pins remain byte-identical to the observed run.

## Supported host and isolation

Use Linux amd64, system Python 3.10.12 and Docker 29.1.3 with its containerd image store. The runner rejects other Docker releases and image stores. Docker access and network access for the exact pinned downloads are required. The driver image uses Python 3.12.12-slim.

The host must already satisfy vm.max_map_count >=262144, hard nofile >=65536, hard process limit >=4096, available RAM >=6 GiB, free disk >=25 GiB, disk use <94%, and >=10,000 free inodes. Cgroup v2 memory, CPU and PID controllers are required. Host setting changes belong to the host owner; the runner does not change these settings or bypass their checks.

Use fresh nonsymlink package extraction and owned directories directly under /var/tmp whose names start with technical-blogs-20261009-opensearch-. The staging directory must exist; both run roots must be absent. Run IDs must match os-20261009-[a-z0-9]{4,16}. Do not adopt leftover resources after a failed run.

OpenSearch is limited to 4 GiB memory+swap, two CPUs, 512 PIDs, a 1 GiB heap and a 512 MiB data tmpfs. The driver is limited to 256 MiB, 0.5 CPU and 128 PIDs. The internal network publishes no ports. Security/demo configuration is disabled only in this unexposed synthetic cluster. No privileged container, added capability, host network or Docker socket mount is used. The JVM explicitly enables bootstrap checks for single-node discovery.

Logs are capped at 10 MiB x3 per container, evidence at 1 GiB, and combined incremental disk at 8 GiB. Sampling occurs every five seconds. The runner stops owned work below 2 GiB available RAM or on a budget breach. Startup is bounded to 180 seconds and the subsequent suite to 600 seconds. Image unpacking projections are estimates; monitored host limits still apply.

## Verify and prepare

Retain the external package-pins.json distributed beside the archive. Set EXECUTION_MANIFEST_SHA256 to its manifest_sha256 value. Do not derive the expected digest from the package being checked. The bootstrap pin below is unchanged. The manifest includes this guide, so its pin is supplied outside the archive.

From inside a fresh extracted opensearch-v4 directory:

```sh
set -eu
LAB_ROOT="$PWD"
BOOTSTRAP="$LAB_ROOT/source/trusted_bootstrap.py"
export PYTHONDONTWRITEBYTECODE=1
: "${EXECUTION_MANIFEST_SHA256:?Supply manifest_sha256 from external package-pins.json}"
printf '%s  %s\n' 575caeea2cc0b6e4ac9d6321f30427cff6bb3066454a664726471ae2e39dc9f5 "$BOOTSTRAP" | sha256sum --check --strict
python3 -I -S -B "$BOOTSTRAP" --package "$LAB_ROOT" --manifest "$LAB_ROOT/execution-manifest.json" --manifest-sha256 "$EXECUTION_MANIFEST_SHA256" --entry package_check -- --package "$LAB_ROOT" --manifest "$LAB_ROOT/execution-manifest.json"
python3 -I -S -B "$BOOTSTRAP" --package "$LAB_ROOT" --manifest "$LAB_ROOT/execution-manifest.json" --manifest-sha256 "$EXECUTION_MANIFEST_SHA256" --entry materialize_references -- --package "$LAB_ROOT"
```

Materialization retrieves individually pinned official source files before launch. It rejects existing destinations and hash mismatches. The supported trust boundary is the system interpreter and standard library, isolated startup (-I -S -B), verified bootstrap and externally pinned manifest. Direct runtime.py or driver.py invocation is unsupported. Undeclared source files, bytecode, import shadows and symlink ancestors fail before local imports.

Optional offline checker controls need fresh output destinations:

```sh
python3 -I -S -B "$BOOTSTRAP" --package "$LAB_ROOT" --manifest "$LAB_ROOT/execution-manifest.json" --manifest-sha256 "$EXECUTION_MANIFEST_SHA256" --entry offline_checks -- --evidence "$LAB_ROOT/offline-original-new"
python3 -I -S -B "$BOOTSTRAP" --package "$LAB_ROOT" --manifest "$LAB_ROOT/execution-manifest.json" --manifest-sha256 "$EXECUTION_MANIFEST_SHA256" --entry os17_offline -- --oracle "$LAB_ROOT/amendments/os17/fixture-expectations.json" --evidence "$LAB_ROOT/offline-os17-new"
```

The main controls expect eight rejected mutations; action-retry controls expect thirteen. A successful control command verifies checker sensitivity, not product behavior.

## Run the synthetic queries

Record an actual cumulative disk baseline before downloads and runs. docker_used_bytes is filesystem used bytes at Docker's data root, not reclaimable image size. If the owned root is on another device, include owned_fs_used_bytes. Keep collection provenance and a GST timestamp beside the values. Inspect source/host.py:disk and source/runtime_verifier.py:incremental_bytes for matching measurements. Do not reset the baseline between runs.

Set SHARED_BASELINE to that JSON, STAGING_ROOT to an existing owned directory, RUN_ROOT_1 and RUN_ROOT_2 to two absent owned directories, and RUN_ID_1 and RUN_ID_2 to unused valid names. Then run:

```sh
: "${SHARED_BASELINE:?Actual cumulative baseline JSON path required}"
: "${STAGING_ROOT:?Existing owned nonsymlink staging directory required}"
: "${RUN_ROOT_1:?Absent owned run root required}"
: "${RUN_ROOT_2:?Second absent owned run root required}"
: "${RUN_ID_1:?Fresh run ID required}"
: "${RUN_ID_2:?Second fresh run ID required}"
python3 -I -S -B "$BOOTSTRAP" --package "$LAB_ROOT" --manifest "$LAB_ROOT/execution-manifest.json" --manifest-sha256 "$EXECUTION_MANIFEST_SHA256" --entry runtime -- preflight --root "$STAGING_ROOT" --shared-baseline "$SHARED_BASELINE"
python3 -I -S -B "$BOOTSTRAP" --package "$LAB_ROOT" --manifest "$LAB_ROOT/execution-manifest.json" --manifest-sha256 "$EXECUTION_MANIFEST_SHA256" --entry runtime -- launch --root "$RUN_ROOT_1" --run-id "$RUN_ID_1" --shared-baseline "$SHARED_BASELINE" --execute-authorized
python3 -I -S -B "$BOOTSTRAP" --package "$LAB_ROOT" --manifest "$LAB_ROOT/execution-manifest.json" --manifest-sha256 "$EXECUTION_MANIFEST_SHA256" --entry runtime -- launch --root "$RUN_ROOT_2" --run-id "$RUN_ID_2" --shared-baseline "$SHARED_BASELINE" --execute-authorized
python3 -I -S -B "$BOOTSTRAP" --package "$LAB_ROOT" --manifest "$LAB_ROOT/execution-manifest.json" --manifest-sha256 "$EXECUTION_MANIFEST_SHA256" --entry runtime -- verify-replay --first "$RUN_ROOT_1/runs/$RUN_ID_1/run-binding.json" --second "$RUN_ROOT_2/runs/$RUN_ID_2/run-binding.json" --output "$LAB_ROOT/replay-results.json"
```

The execute-authorized flag records the operator's decision to run. Stop on a nonzero launch or failed cleanup. The runner verifies product version/build, pinned image identity, configuration, mapping and create/readback before fixture writes. It executes the queries automatically; there is no published query endpoint or manual query window.

Each run exports raw request/response evidence before deleting its exact owned indexes and stopping the volatile cluster. Cleanup verifies exact container/network identities and unchanged unrelated containers. Evidence and pinned image layers remain. No broad prune or wildcard deletion is used. Finalization-success.json is written only after monitoring stops and owned cleanup succeeds. Replay rejects a missing receipt or changed binding.

## Interpret and inspect results

The main corpus has five tenant/job histories, two tenants and 33 events (alpha 27, beta 6). Q01 returns nine retry events in pages 3/3/3/0. Q02 returns six COMPUTE_STARTED buckets in pages of two, using returned after_key cursors. Q03 returns two failure records. Q04 selects HOLD_UNKNOWN. Q05 retains contradictory completion/failure records. Q06 checks tenant selection; it does not test authorization.

The separate action-retry index has eight events with pages 3/3/2/0. Sequences 5 and 7 record confirmations sharing one action ID and distinct event IDs; sequence 6 records STARTED for attempt 2. Attempt 1 has no COMPLETED. The complete expected documents are in amendments/os17/fixture-expectations.json, and the request is source/queries/OS17.timeline.json. Ingestion remains paused throughout both search_after walks. Each page must have exact total, no timeout and zero failed shards.

Your run's action-retry bundle is under <run-root>/runs/<run-id>/OS17/bundle.json. Parse each page's raw_body as JSON and inspect hits.hits. Recheck the bundle with its retained binding:

```sh
OS17_EVIDENCE="$RUN_ROOT_1/runs/$RUN_ID_1/OS17"
python3 -I -S -B "$BOOTSTRAP" --package "$LAB_ROOT" --manifest "$LAB_ROOT/execution-manifest.json" --manifest-sha256 "$EXECUTION_MANIFEST_SHA256" --entry os17_check -- --bundle "$OS17_EVIDENCE/bundle.json" --oracle "$OS17_EVIDENCE/expected.json" --binding "$OS17_EVIDENCE/binding.json"
```

The companion results/raw-summary.json and results/os17-pages-v4a.json / results/os17-pages-v4b.json retain the observed results from 10 October 2026 GST. The package's live-status.json describes that observation; it is not a new execution claim.

All events and timestamps are authored fixtures. ACTION_CONFIRMED is a producer record, not an external receipt or a business-effect count. No model, tool or actual worker restart runs. Sequence is producer ordering, not _seq_no or distributed ordering. Sequence uniqueness is validated within a submitted batch; producers maintain it across batches. Plain search_after is bounded to paused ingestion. Volatile storage demonstrates no restart durability, persistence, concurrent-writer snapshot, tenant access control or exactly-once guarantee.

versions.lock.json retains immutable image descriptors, source URLs and reviewed source contracts. Effective settings merge defaults, persistent settings and then transient settings; a transient disk-threshold disable overrides persistent enable and is rejected. settings-precedence-source.json binds the corresponding source. Image metadata establishes pin identity; actual runtime identity is checked by each run.
