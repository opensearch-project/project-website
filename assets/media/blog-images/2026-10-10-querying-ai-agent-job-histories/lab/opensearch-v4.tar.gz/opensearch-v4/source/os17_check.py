"""OS17 checker process; invalid bundles exit one with an explicit failure."""

import argparse
import json
import os17_verifier
import verifier as v


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--bundle", required=True)
    parser.add_argument("--oracle", required=True)
    parser.add_argument("--binding", required=True)
    args = parser.parse_args()
    try:
        result = os17_verifier.verify(v.load(args.bundle), v.load(args.oracle), v.load(args.binding))
    except Exception as error:
        print(json.dumps({"status": "REJECTED", "error": f"{type(error).__name__}: {error}"}))
        return 1
    print(json.dumps({"status": "VALID_BUNDLE", "interpretation": result["label"], "live_claim": False}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
