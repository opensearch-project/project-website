"""Product E2E entrypoint, executed only inside the task-owned driver container."""

import sys

if not hasattr(sys, '_opensearch_verified_package'):
    raise SystemExit('use the pinned trusted bootstrap with python3 -I -S -B')

import argparse
import time
from pathlib import Path

from e2e import Suite
import os17_e2e
from transport import Client, write_json
import verifier as v


def readiness(client, run_id):
    deadline = client.deadline
    while time.monotonic() < deadline:
        try:
            body = client.request("readiness-poll", "GET", "/", statuses=(200, 503))
        except ConnectionRefusedError:
            time.sleep(1)
            continue
        if "version" not in body:
            time.sleep(1)
            continue
        v.equal(body["version"]["number"], "3.9.0", "wrong readiness version")
        v.equal(body["cluster_name"], run_id, "wrong readiness cluster")
        return
    raise TimeoutError("180-second readiness deadline")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--evidence", required=True)
    parser.add_argument("--identity", required=True)
    parser.add_argument("--startup-deadline", required=True, type=float)
    args = parser.parse_args()
    evidence = Path(args.evidence)
    evidence.mkdir(parents=True, exist_ok=True)
    identity = v.load(args.identity)
    client = Client("opensearch", evidence)
    client.deadline = args.startup_deadline
    try:
        readiness(client, args.run_id)
        suite = Suite(client, args.run_id, evidence, identity)
        suite.run()
        os17_e2e.run(suite)
    except Exception as error:
        os17_e2e.blocked(evidence)
        write_json(evidence / "failure.json", {"status": "FAIL", "error": f"{type(error).__name__}: {error}"})
        raise


if __name__ == "__main__":
    main()
