"""Read-only official registry/source resolution. Tokens stay only in memory."""

import argparse
import hashlib
import json
import re
import urllib.request
import urllib.error
import urllib.parse
from pathlib import Path

from transport import now, write_json
import verifier as v


ACCEPT = ", ".join(["application/vnd.oci.image.index.v1+json", "application/vnd.docker.distribution.manifest.list.v2+json", "application/vnd.oci.image.manifest.v1+json", "application/vnd.docker.distribution.manifest.v2+json"])


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, request, file, code, message, headers, new_url):
        raise ValueError(f"redirect forbidden: HTTP {code}; Location omitted")


class RegistryBlobRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, request, file, code, message, headers, new_url):
        return None


def registry_config(url, headers, output, digest):
    opener = urllib.request.build_opener(RegistryBlobRedirect)
    request = urllib.request.Request(url, headers=headers)
    try:
        with opener.open(request, timeout=15) as response:
            raw = response.read(2 * 1024 ** 2 + 1)
        delivery = "registry-direct"
    except urllib.error.HTTPError as error:
        v.equal(error.code, 307, "only registry blob delivery HTTP 307 supported")
        location = error.headers["Location"]
        parsed = urllib.parse.urlsplit(location)
        v.equal(parsed.scheme, "https", "registry delivery HTTPS required")
        v.require(parsed.hostname in {"production.cloudflare.docker.com", "production.cloudfront.docker.com"}, "unrecognized official registry blob delivery host")
        raw = delivery_bytes(location)
        delivery = parsed.hostname
    v.require(len(raw) <= 2 * 1024 ** 2, "registry config oversized")
    checked_digest(raw, digest)
    (output / "config.body").write_bytes(raw)
    write_json(output / "config.json", {"url": url, "sha256": hashlib.sha256(raw).hexdigest(), "retrieved_gst": now(), "delivery_host": delivery, "protocol": "explicit single registry-directed blob GET; no automatic redirect; no bearer forwarded; signed URL omitted", "status": 200})
    return raw


def delivery_bytes(location):
    try:
        opener = urllib.request.build_opener(NoRedirect)
        with opener.open(urllib.request.Request(location), timeout=15) as response:
            return response.read(2 * 1024 ** 2 + 1)
    except Exception as error:
        raise ValueError("official registry blob delivery failed; signed URL omitted; " + type(error).__name__) from None


PRODUCT_SOURCES = {
    "bulk": ("server/src/main/java/org/opensearch/action/bulk/BulkResponse.java", "hasFailures"),
    "create-conflict": ("server/src/main/java/org/opensearch/index/VersionType.java", "MATCH_DELETED"),
    "conflict-status": ("server/src/main/java/org/opensearch/index/engine/VersionConflictEngineException.java", "CONFLICT"),
    "refresh-wait-for": ("server/src/main/java/org/opensearch/action/support/WriteRequest.java", "wait_for"),
    "strict-mapping": ("server/src/main/java/org/opensearch/index/mapper/DocumentParser.java", "StrictDynamicMappingException"),
    "search-after": ("server/src/main/java/org/opensearch/search/searchafter/SearchAfterBuilder.java", "buildFieldDoc"),
    "composite": ("server/src/main/java/org/opensearch/search/aggregations/bucket/composite/CompositeAggregationBuilder.java", "aggregateAfter"),
    "disk-defaults": ("server/src/main/java/org/opensearch/cluster/routing/allocation/DiskThresholdSettings.java", "85%"),
    "bootstrap": ("server/src/main/java/org/opensearch/bootstrap/BootstrapChecks.java", "1 << 18"),
    "numeric-types": ("server/src/main/java/org/opensearch/index/mapper/NumberFieldMapper.java", "coerce"),
    "date-format": ("server/src/main/java/org/opensearch/common/time/DateFormatters.java", "strict_date_time"),
    "search-response": ("server/src/main/java/org/opensearch/action/search/SearchResponse.java", "timed_out"),
    "search-totals": ("server/src/main/java/org/opensearch/search/SearchHits.java", "relation"),
    "search-shards": ("server/src/main/java/org/opensearch/rest/action/RestActions.java", "_shards"),
    "search-builder": ("server/src/main/java/org/opensearch/search/builder/SearchSourceBuilder.java", "trackTotalHits"),
    "create-operation": ("server/src/main/java/org/opensearch/action/index/IndexRequest.java", "CREATE"),
    "bulk-api": ("rest-api-spec/src/main/resources/rest-api-spec/api/bulk.json", "wait_for"),
    "source-retention": ("server/src/main/java/org/opensearch/index/mapper/SourceFieldMapper.java", "enabled"),
    "explicit-refresh": ("server/src/main/java/org/opensearch/rest/action/admin/indices/RestRefreshAction.java", "RefreshRequest")
}


def fetch(url, directory, name, headers=None):
    request = urllib.request.Request(url, headers=headers or {})
    opener = urllib.request.build_opener(NoRedirect)
    with opener.open(request, timeout=15) as response:
        v.equal(response.geturl(), url, "redirect not allowed in release checks")
        data = response.read(2 * 1024 ** 2 + 1)
        v.require(len(data) <= 2 * 1024 ** 2, "release/source response oversized")
        metadata = {"url": url, "status": response.status, "sha256": hashlib.sha256(data).hexdigest(), "retrieved_gst": now()}
        if "Docker-Content-Digest" in response.headers:
            metadata["registry_digest"] = response.headers["Docker-Content-Digest"]
    if name != "token":
        directory.mkdir(parents=True, exist_ok=True)
        (directory / f"{name}.body").write_bytes(data)
        write_json(directory / f"{name}.json", metadata)
    return data, metadata


def checked_digest(data, expected):
    actual = "sha256:" + hashlib.sha256(data).hexdigest()
    v.equal(actual, expected, "registry/blob digest mismatch")


def registry(repository, tag, output):
    token_url = f"https://auth.docker.io/token?service=registry.docker.io&scope=repository:{repository}:pull"
    token_raw, _ = fetch(token_url, output, "token")
    token = json.loads(token_raw)["token"]
    headers = {"Authorization": "Bearer " + token, "Accept": ACCEPT}
    base = f"https://registry-1.docker.io/v2/{repository}"
    raw, metadata = fetch(f"{base}/manifests/{tag}", output, "index", headers)
    checked_digest(raw, metadata["registry_digest"])
    index = json.loads(raw)
    children = [child for child in index["manifests"] if child["platform"].get("os") == "linux" and child["platform"].get("architecture") == "amd64"]
    v.equal(len(children), 1, "one Linux amd64 child required")
    child = children[0]["digest"]
    raw, child_metadata = fetch(f"{base}/manifests/{child}", output, "linux-amd64", headers)
    checked_digest(raw, child)
    manifest = json.loads(raw)
    config_digest = manifest["config"]["digest"]
    config_raw = registry_config(f"{base}/blobs/{config_digest}", headers, output, config_digest)
    checked_digest(config_raw, config_digest)
    v.equal(len(config_raw), manifest["config"]["size"], "config descriptor size")
    config = json.loads(config_raw)
    v.equal(config["architecture"], "amd64", "image architecture")
    v.equal(config["os"], "linux", "image OS")
    return {"repository": repository, "tag": tag, "index_digest": metadata["registry_digest"], "platform_digest": child, "reference": f"{repository}@{child}", "config_digest": config_digest, "compressed_layer_bytes": sum(layer["size"] for layer in manifest["layers"]), "image_user": config["config"].get("User", ""), "status": "MANIFEST_VERIFIED", "child_response_sha256": child_metadata["sha256"]}


def product_sources(output):
    ref_url = "https://api.github.com/repos/opensearch-project/OpenSearch/git/ref/tags/3.9.0"
    raw, _ = fetch(ref_url, output, "tag")
    obj = json.loads(raw)["object"]
    if obj["type"] == "tag":
        tag_raw, _ = fetch(obj["url"], output, "annotated-tag")
        obj = json.loads(tag_raw)["object"]
    v.equal(obj["type"], "commit", "release tag must resolve to commit")
    commit = obj["sha"]
    v.require(re.fullmatch(r"[0-9a-f]{40}", commit) is not None, "invalid source commit")
    claims = []
    for claim, (path, marker) in PRODUCT_SOURCES.items():
        url = f"https://raw.githubusercontent.com/opensearch-project/OpenSearch/{commit}/{path}"
        raw, metadata = fetch(url, output, claim)
        v.require(marker.encode() in raw, f"contract marker absent for {claim}; manual source review required")
        claims.append({"claim": claim, "url": url, "commit": commit, "sha256": metadata["sha256"], "status": "REVIEW_REQUIRED", "marker": marker})
    return {"commit": commit, "claims": claims, "status": "REVIEW_REQUIRED"}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    result = {"status": "BLOCKED", "retrieved_gst": now(), "runtime_requests": 0}
    try:
        result["opensearch"] = registry("opensearchproject/opensearch", "3.9.0", output / "opensearch")
        result["driver"] = registry("library/python", "3.12.12-slim", output / "driver")
        result["source"] = product_sources(output / "source")
        result["status"] = "REVIEW_REQUIRED"
    except Exception as error:
        result["error"] = f"{type(error).__name__}: {error}"
        raise
    finally:
        write_json(output / "resolution.json", result)


if __name__ == "__main__":
    main()
