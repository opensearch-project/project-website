"""Verify a package's frozen file manifest before any runtime creation."""

import argparse
import hashlib
from pathlib import Path
import verifier as v


def no_symlink_ancestors(path):
    for item in [path, *path.parents]:
        v.require(not item.is_symlink(), "package symlink or ancestor escape: " + str(item))


def declared_path(package, relative):
    path = Path(relative)
    v.require(not path.is_absolute() and ".." not in path.parts, "manifest path traversal")
    v.equal(path.as_posix(), relative, "noncanonical manifest path")
    target = package / path
    no_symlink_ancestors(target)
    v.require(target.is_file(), "declared file missing or not regular: " + relative)
    return target


def source_inventory(package):
    boundary = package / "source"
    no_symlink_ancestors(boundary)
    v.require(boundary.is_dir(), "source execution boundary missing")
    pending, files = [boundary], set()
    while pending:
        for path in pending.pop().iterdir():
            v.require(not path.is_symlink(), "source inventory symlink")
            if path.is_dir():
                pending.append(path)
            else:
                v.require(path.is_file(), "source inventory nonregular entry")
                files.add(path.relative_to(package).as_posix())
    return files


def verify(package, manifest):
    package, manifest = Path(package).absolute(), Path(manifest).absolute()
    no_symlink_ancestors(package)
    no_symlink_ancestors(manifest)
    v.require(manifest.is_relative_to(package), "manifest outside package")
    value = v.load(manifest)
    v.equal(value["execution_boundary"], "source", "exact mounted source boundary")
    declared = set(value["files"])
    source = {name for name in declared if Path(name).parts[0] == "source"}
    v.equal(source_inventory(package), source, "exact mounted source inventory")
    v.equal(set(value["non_source_artifacts"]), declared - source, "explicit non-source artifact inventory")
    for relative, digest in value["files"].items():
        target = declared_path(package, relative)
        v.equal(hashlib.sha256(target.read_bytes()).hexdigest(), digest, "frozen package bytes: " + relative)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--package", required=True)
    parser.add_argument("--manifest", required=True)
    args = parser.parse_args()
    verify(Path(args.package), Path(args.manifest))


if __name__ == "__main__":
    main()
