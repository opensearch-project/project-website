"""Bind lock claims to retained official bytes before any runtime creation."""

import hashlib
import json
import re
from pathlib import Path

from release_check import PRODUCT_SOURCES
import verifier as v


def artifact(package, relative, digest):
    path = Path(relative)
    v.require(not path.is_absolute(), "pin artifact must be package-relative")
    v.require(".." not in path.parts, "pin artifact path traversal")
    path = package / path
    for ancestor in [path, *path.parents]:
        v.require(not ancestor.is_symlink(), "pin artifact symlink rejected")
    raw = path.read_bytes()
    v.equal(hashlib.sha256(raw).hexdigest(), digest.removeprefix("sha256:"), "pin artifact bytes changed")
    return raw


def registry_bytes(package, image):
    files = image["registry_artifacts"]
    index = json.loads(artifact(package, files["index"], image["index_digest"]))
    child = json.loads(artifact(package, files["platform"], image["platform_digest"]))
    config = json.loads(artifact(package, files["config"], image["config_digest"]))
    expected = [entry["digest"] for entry in index["manifests"] if entry["platform"]["os"] == "linux" and entry["platform"]["architecture"] == "amd64"]
    v.equal(expected, [image["platform_digest"]], "official platform descriptor")
    v.equal(child["config"]["digest"], image["config_digest"], "image config descriptor")
    v.equal(config["architecture"], "amd64", "config architecture")
    v.equal(config["os"], "linux", "config OS")
    v.equal(sum(layer["size"] for layer in child["layers"]), image["compressed_layer_bytes"], "layer budget inputs")
    v.require(bool(image["projection_method"]), "uncompressed size estimate provenance missing")
    return config


def source_ledger(package, pins):
    v.require(re.fullmatch(r"[0-9a-f]{40}", pins["release_commit"]) is not None, "immutable release commit required")
    ledger = pins["source_contracts"]
    v.equal({claim["claim"] for claim in ledger}, set(PRODUCT_SOURCES), "complete version-specific source ledger")
    for claim in ledger:
        v.equal(claim["status"], "SOURCE_VERIFIED", "source review incomplete")
        expected_url = "https://raw.githubusercontent.com/opensearch-project/OpenSearch/" + pins["release_commit"] + "/" + PRODUCT_SOURCES[claim["claim"]][0]
        v.equal(claim["url"], expected_url, "immutable official source URL")
        artifact(package, claim["artifact"], claim["sha256"])
        v.require(bool(claim["reviewed_contract"]), "source contract review missing")
    user = pins["runtime_user"]
    v.require(re.fullmatch(r"https://raw\.githubusercontent\.com/opensearch-project/[A-Za-z0-9._-]+/[0-9a-f]{40}/.+", user["source_url"]) is not None, "immutable official image-user source required")
    artifact(package, user["source_artifact"], user["source_sha256"])


def verify(package, pins):
    configs = {role: registry_bytes(package, pins[role]) for role in ("opensearch", "driver")}
    source_ledger(package, pins)
    v.equal(configs["opensearch"]["config"]["User"], pins["runtime_user"]["image_user"], "runtime-user config binding")


def referenced_files(pins):
    paths = [path for role in ("opensearch", "driver") for path in pins[role]["registry_artifacts"].values()]
    paths.extend(claim["artifact"] for claim in pins["source_contracts"])
    paths.append(pins["runtime_user"]["source_artifact"])
    return paths
