"""Offline sensitivity checks only. Never treated as OpenSearch execution evidence."""

import copy
import argparse
import json
import subprocess
import sys
from pathlib import Path

import application
import e2e
import verifier as v
from transport import now, write_json


EVIDENCE = None


def process_rejection(mode, actual, expected, name):
    write_json(EVIDENCE / f"{name}.actual.json", actual)
    write_json(EVIDENCE / f"{name}.expected.json", expected)
    argv = [sys.executable, str(Path(__file__).with_name("verify_cli.py")), "--mode", mode, "--actual", str(EVIDENCE / f"{name}.actual.json"), "--expected", str(EVIDENCE / f"{name}.expected.json")]
    started = now()
    result = subprocess.run(argv, capture_output=True, timeout=15, check=False)
    (EVIDENCE / f"{name}.stdout").write_bytes(result.stdout)
    (EVIDENCE / f"{name}.stderr").write_bytes(result.stderr)
    record = {"scope": "OFFLINE_ONLY", "synthetic_checker_input": True, "product_requests": 0, "argv": argv, "cwd": str(Path.cwd()), "start_gst": started, "end_gst": now(), "timeout_seconds": 15, "exit": result.returncode, "expected_exit": 1, "stdout": f"{name}.stdout", "stderr": f"{name}.stderr"}
    with (EVIDENCE / "commands.jsonl").open("a") as file:
        file.write(json.dumps(record, sort_keys=True) + "\n")
    v.equal(result.returncode, 1, "offline checker must reject with nonzero exit")


def schema_checks(raw):
    for bad in e2e.application_invalid_inputs(raw):
        v.rejects(application.sanitize_batch, bad)
    invalid = copy.deepcopy(raw)
    invalid["tenant_id"] = "FAKE_SECRET/INVALID"
    v.rejects(application.sanitize, invalid)
    invalid = copy.deepcopy(raw)
    invalid["schema_version"] = True
    v.rejects(application.sanitize, invalid)
    process_rejection("schema", invalid, {}, "schema-wrong-type")


def redaction_checks(raw):
    contaminated = copy.deepcopy(raw)
    contaminated.update({"prompt": e2e.MARKERS[0], "debug": {"header": e2e.MARKERS[1]}, "output": e2e.MARKERS[2]})
    doc = application.sanitize(contaminated)
    v.redacted(doc, e2e.MARKERS, application.FIELDS)
    bad = copy.deepcopy(doc)
    bad["extra"] = "unlisted"
    v.rejects(v.redacted, bad, [], application.FIELDS)
    process_rejection("redaction", bad, {"markers": [], "allowed": application.FIELDS}, "redaction-unlisted")
    bad["extra"] = e2e.MARKERS[0]
    v.rejects(v.redacted, bad, e2e.MARKERS, application.FIELDS)
    process_rejection("redaction", bad, {"markers": e2e.MARKERS, "allowed": application.FIELDS}, "redaction-marker")


def fixture_checks(raw, oracle):
    docs = application.sanitize_batch(raw)
    v.equal(len(docs), 33, "fixture count")
    fixture_histories(docs, oracle)
    fixture_counts(docs, oracle)
    fixture_ties(docs)
    v.require(all(len(application.canonical(doc)) < 4096 for doc in docs), "document size")


def fixture_histories(docs, oracle):
    for job, expected_ids in oracle["histories"].items():
        selected = [doc for doc in docs if doc["tenant_id"] + "/" + doc["job_id"] == job]
        selected.sort(key=application.producer_sequence)
        v.equal([doc["event_id"] for doc in selected], expected_ids, "fixture IDs")
        v.equal([doc["event_type"] for doc in selected], oracle["event_types"][job], "fixture types")


def fixture_counts(docs, oracle):
    v.equal(len([doc for doc in docs if doc["tenant_id"] == "alpha"]), 27, "alpha count")
    for event_type in ("COMPUTE_STARTED", "COMPUTE_FAILED", "JOB_FAILED", "HOLD_UNKNOWN", "COMPLETED"):
        v.equal(len([doc for doc in docs if doc["event_type"] == event_type]), oracle["counts"][event_type], "type count")


def fixture_ties(docs):
    tied = [doc for doc in docs if doc["event_id"] in ("alpha:job-ok:a1:s04", "alpha:job-ok:a1:s05")]
    v.equal(tied[0]["sequence"], 5, "reverse tie insertion")
    v.equal(tied[0]["event_time"], tied[1]["event_time"], "fixture tied time")
    v.equal(tied[0]["ingested_at"], tied[1]["ingested_at"], "fixture tied ingestion time")


def bulk_controls(oracle):
    expected = oracle["OS12"]
    items = [{"create": {"_id": event_id, "status": status, "error": {"type": category}}} for event_id, status, category in zip(expected["ids"], expected["statuses"], expected["error_types"])]
    synthetic = {"errors": True, "items": items}
    for mutate in (e2e.omit_bulk_item, e2e.clear_bulk_error):
        bad = copy.deepcopy(synthetic)
        mutate(bad)
        v.rejects(v.bulk, bad, expected["ids"], expected["statuses"], expected["error_types"])
        process_rejection("bulk", bad, expected, mutate.__name__)


def search_controls():
    synthetic = {"timed_out": False, "_shards": {"total": 1, "successful": 1, "failed": 0}, "hits": {"total": {"value": 0, "relation": "eq"}, "hits": []}}
    for mutate in (e2e.shard_failure, e2e.timed_out):
        bad = copy.deepcopy(synthetic)
        mutate(bad)
        v.rejects(v.history, bad, [])
        process_rejection("history", bad, [], mutate.__name__)
    synthetic["hits"]["total"]["relation"] = "gte"
    v.rejects(v.history, synthetic, [])
    process_rejection("history", synthetic, [], "inexact-total")


def main():
    global EVIDENCE
    parser = argparse.ArgumentParser()
    parser.add_argument("--evidence", required=True)
    args = parser.parse_args()
    EVIDENCE = Path(args.evidence)
    EVIDENCE.mkdir(parents=True, exist_ok=False)
    root = Path(__file__).parent
    raw = v.load(root / "fixtures.json")
    oracle = v.load(root / "fixture-expectations.json")
    fixture_checks(raw, oracle)
    schema_checks(raw[0])
    redaction_checks(raw[0])
    bulk_controls(oracle)
    search_controls()
    print(json.dumps({"status": "PASS", "scope": "OFFLINE_ONLY", "product_requests": 0, "checks": ["literal-fixture-oracle", "schema-rejection", "redaction", "bulk-negative-controls", "search-negative-controls"]}))


if __name__ == "__main__":
    main()
