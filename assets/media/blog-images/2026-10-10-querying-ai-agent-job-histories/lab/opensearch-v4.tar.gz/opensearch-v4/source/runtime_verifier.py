"""Independent host/resource checks for OS01, OS15 and OS16."""

from pathlib import Path

import verifier as v


GIB = 1024 ** 3


def host(sample, shared_baseline, available_minimum=6 * GIB):
    v.equal(sample["architecture"], "x86_64", "host architecture")
    v.require(sample["vm_max_map_count"] >= 262144, "vm.max_map_count prerequisite blocked")
    v.require(sample["memory_available_bytes"] >= available_minimum, "available RAM gate")
    for filesystem in (sample["docker_disk"], sample["owned_root_disk"]):
        disk_budget(filesystem)
    delta = incremental_bytes(sample, shared_baseline)
    v.require(delta <= 8 * GIB, "combined incremental disk gate")
    v.require(sample["evidence_bytes"] <= GIB, "evidence budget")
    v.require(sample["nofile_hard"] >= 65536, "file limit prerequisite")
    v.require(sample["nproc_hard"] >= 4096, "process limit prerequisite")
    v.equal(sample["cgroup_memory_limit_supported"], True, "cgroup memory limits")
    v.equal(sample["cgroup_pids_supported"], True, "cgroup PID limits")
    v.equal(sample["cgroup_cpu_limit_supported"], True, "cgroup CPU limits")


def disk_budget(filesystem):
    v.require(filesystem["free_bytes"] >= 25 * GIB, "minimum free disk gate")
    v.require(filesystem["used_ratio"] < 0.94, "maximum disk usage gate")
    v.require(filesystem["free_inodes"] >= 10000, "inode gate")


def incremental_bytes(sample, baseline):
    delta = sample["docker_disk"]["used_bytes"] - baseline["docker_used_bytes"]
    if sample["docker_disk"]["device"] != sample["owned_root_disk"]["device"]:
        delta += sample["owned_root_disk"]["used_bytes"] - baseline["owned_fs_used_bytes"]
    return delta


def owned_path(path, must_exist=False):
    path = Path(path)
    v.require(path.is_absolute(), "owned path must be absolute")
    v.require(path.name.startswith("technical-blogs-20261009-opensearch-"), "owned root prefix")
    v.equal(str(path.parent), "/var/tmp", "owned root parent")
    for ancestor in [path, *path.parents]:
        v.require(not ancestor.is_symlink(), "symlink ancestor rejected")
    v.equal(path.exists(), must_exist, "owned path collision/existence")


def container(inspect, network_id, image_id, role):
    spec = {"opensearch": (4 * GIB, 2000000000, 512), "driver": (256 * 1024 ** 2, 500000000, 128)}[role]
    config = inspect["HostConfig"]
    v.equal(inspect["Image"], image_id, "local image identity")
    v.equal(config["Memory"], spec[0], "memory limit")
    v.equal(config["MemorySwap"], spec[0], "memory+swap limit")
    v.equal(config["NanoCpus"], spec[1], "CPU limit")
    v.equal(config["PidsLimit"], spec[2], "PID limit")
    v.equal(config["Privileged"], False, "privileged forbidden")
    v.require(not config["PortBindings"], "published ports forbidden")
    v.require(not config.get("CapAdd"), "added capabilities forbidden")
    networks = list(inspect["NetworkSettings"]["Networks"].values())
    v.equal(len(networks), 1, "unrelated network attachment")
    v.equal(networks[0]["NetworkID"], network_id, "owned network")
    v.equal(config["LogConfig"], {"Type": "json-file", "Config": {"max-size": "10m", "max-file": "3"}}, "log bounds")
    for mount in inspect["Mounts"]:
        v.require("docker.sock" not in mount.get("Source", ""), "Docker socket mount forbidden")


def opensearch_mount(identity):
    mount = identity["data_mount"]
    v.equal(identity['configured_data_root'], '/usr/share/opensearch/data', 'configured mount root')
    v.equal(mount['path'], identity['configured_data_root'], 'actual mount root')
    v.equal(mount["type"], "tmpfs", "data filesystem")
    v.equal(mount["capacity_bytes"], 512 * 1024 ** 2, "data capacity")
    v.equal(mount["uid"], identity["runtime_uid"], "data UID")
    v.equal(mount["gid"], identity["runtime_gid"], "data GID")
    v.equal(identity["actual_uid"], identity["runtime_uid"], "actual runtime UID")
    v.equal(identity["actual_gid"], identity["runtime_gid"], "actual runtime GID")


def unchanged_unrelated(before, after):
    for container_id, status in before.items():
        v.equal(after.get(container_id), status, "unrelated container status changed")


def shutdown(inspects, removed, owned_ids):
    v.equal(set(removed), set(owned_ids), "cleanup exact ownership")
    for inspect in inspects:
        v.equal(inspect["State"]["OOMKilled"], False, "OOM")
        v.equal(inspect["RestartCount"], 0, "restart")


def repeatability(first, second):
    v.require(first["run_id"] != second["run_id"], "fresh run required")
    v.require(first["network_id"] != second["network_id"], "fresh network required")
    v.require(first["main_index"] != second["main_index"], "fresh index required")
    v.require(first["os17_index"] != second["os17_index"], "fresh OS17 index required")
    v.equal(first["source_hashes"], second["source_hashes"], "replay source identity")
    v.equal(first["pins"], second["pins"], "replay image pins")
    v.equal(first["semantics"], second["semantics"], "replay semantic results")
    v.equal(first["suite_status"], "PASS", "first suite")
    v.equal(second["suite_status"], "PASS", "second suite")
