"""Sanitize synthetic events, build bounded queries, and interpret recorded claims."""

import copy
import hashlib
import json
import re
from datetime import datetime


FIELDS = ("schema_version", "tenant_id", "job_id", "event_id", "event_type", "attempt", "sequence", "event_time", "ingested_at", "action_id")
REQUIRED = FIELDS[:-1]
JOBS = {"alpha": {"job-ok", "job-retry", "job-unknown", "job-late", "job-action-retry"}, "beta": {"job-ok"}}
EVENT_TYPES = {"STARTED", "COMPUTE_STARTED", "COMPUTE_FINISHED", "COMPUTE_FAILED", "ACTION_REQUESTED", "ACTION_CONFIRMED", "HOLD_UNKNOWN", "COMPLETED", "JOB_FAILED"}
ACTION_TYPES = {"ACTION_REQUESTED", "ACTION_CONFIRMED", "HOLD_UNKNOWN"}
IDENTIFIER = re.compile(r"[A-Za-z0-9][A-Za-z0-9:._-]{0,127}", re.ASCII)
TIMESTAMP = re.compile(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}[+-]\d{2}:\d{2}", re.ASCII)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def canonical(doc):
    return json.dumps(doc, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode()


def document_hash(doc):
    return hashlib.sha256(canonical(doc)).hexdigest()


def identifier(value, field):
    require(type(value) is str, f"{field} must be a string")
    require(IDENTIFIER.fullmatch(value) is not None, f"{field} invalid identifier")


def positive_integer(value, field, maximum):
    require(type(value) is int, f"{field} must be an integer without coercion")
    require(0 < value <= maximum, f"{field} outside permitted range")


def timestamp(value, field):
    require(type(value) is str, f"{field} must be a timestamp string")
    require(TIMESTAMP.fullmatch(value) is not None, f"{field} must use strict_date_time")
    parsed = datetime.fromisoformat(value)
    require(parsed.utcoffset() is not None, f"{field} requires timezone")


def validate_identity(doc):
    for field in ("tenant_id", "job_id", "event_id", "event_type"):
        identifier(doc[field], field)
    require(doc["tenant_id"] in JOBS, "tenant is not fixture-owned")
    require(doc["job_id"] in JOBS[doc["tenant_id"]], "job is not fixture-owned")
    require(doc["event_type"] in EVENT_TYPES, "event_type outside enum")
    event_id = f"{doc['tenant_id']}:{doc['job_id']}:a{doc['attempt']}:s{doc['sequence']:02d}"
    require(doc["event_id"] == event_id, "event_id must bind tenant/job/attempt/sequence")


def validate_action(doc):
    if doc["event_type"] not in ACTION_TYPES:
        require("action_id" not in doc, "action_id forbidden for this event type")
        return
    require("action_id" in doc, "action_id required for action event")
    identifier(doc["action_id"], "action_id")
    require(doc["action_id"] == f"{doc['tenant_id']}:{doc['job_id']}:followup:v1", "action_id must be stable across attempts")


def sanitize(raw):
    require(type(raw) is dict, "event must be an object")
    require(set(REQUIRED) <= raw.keys(), "required event field missing")
    doc = {field: raw[field] for field in FIELDS if field in raw}
    require(type(doc["schema_version"]) is int, "schema_version integer required")
    require(doc["schema_version"] == 1, "schema_version must be 1")
    positive_integer(doc["attempt"], "attempt", 100)
    positive_integer(doc["sequence"], "sequence", 99)
    validate_identity(doc)
    timestamp(doc["event_time"], "event_time")
    timestamp(doc["ingested_at"], "ingested_at")
    validate_action(doc)
    require(len(canonical(doc)) < 4096, "event exceeds fixture document limit")
    return doc


def sanitize_batch(raw_events):
    docs = [sanitize(raw) for raw in raw_events]
    sequences = set()
    for doc in docs:
        key = (doc["tenant_id"], doc["job_id"], doc["sequence"])
        require(key not in sequences, "producer sequence reused within tenant/job")
        sequences.add(key)
    return docs


def ndjson(docs):
    lines = []
    for doc in docs:
        lines.append(canonical({"create": {"_id": doc["event_id"]}}))
        lines.append(canonical(doc))
    return b"\n".join(lines) + b"\n"


def classify_conflict(submitted, stored):
    if canonical(submitted) == canonical(stored):
        return "DUPLICATE"
    return "CONFLICTING_EVENT"


def producer_sequence(doc):
    return doc["sequence"]


def history_request(tenant, job, size=100):
    return {"size": size, "track_total_hits": True, "query": {"bool": {"filter": [{"term": {"tenant_id": tenant}}, {"term": {"job_id": job}}]}}, "sort": [{"sequence": "asc"}, {"event_id": "asc"}]}


def tenant_request(tenant):
    return {"size": 100, "track_total_hits": True, "query": {"bool": {"filter": [{"term": {"tenant_id": tenant}}]}}, "sort": [{"event_id": "asc"}]}


def search_after(client, index, definition, name):
    request = copy.deepcopy(definition)
    pages = []
    requests = []
    for page_number in range(100):
        requests.append(copy.deepcopy(request))
        body = client.request(f"{name}-page-{page_number}", "POST", f"/{index}/_search", request)
        pages.append(body)
        hits = body["hits"]["hits"]
        if not hits:
            return pages, requests
        request["search_after"] = hits[-1]["sort"]
    raise ValueError("search_after exceeded bounded page count")


def composite(client, index, definition, name):
    request = copy.deepcopy(definition)
    pages = []
    requests = []
    for page_number in range(100):
        requests.append(copy.deepcopy(request))
        body = client.request(f"{name}-page-{page_number}", "POST", f"/{index}/_search", request)
        pages.append(body)
        aggregation = body["aggregations"]["attempts"]
        if not aggregation["buckets"]:
            return pages, requests
        if "after_key" not in aggregation:
            return pages, requests
        request["aggs"]["attempts"]["composite"]["after"] = aggregation["after_key"]
    raise ValueError("composite exceeded bounded page count")


def retry_jobs(pages):
    attempts = {}
    for page in pages:
        for bucket in page["aggregations"]["attempts"]["buckets"]:
            key = bucket["key"]
            job = f"{key['tenant']}/{key['job']}"
            attempts.setdefault(job, set()).add(key["attempt"])
    return sorted(job for job, recorded in attempts.items() if len(recorded) > 1)


def interpret_history(docs):
    completed = {doc["attempt"] for doc in docs if doc["event_type"] == "COMPLETED"}
    failed = {doc["attempt"] for doc in docs if doc["event_type"] == "JOB_FAILED"}
    conflicts = completed & failed
    if conflicts:
        support = [doc["event_id"] for doc in docs if doc["attempt"] in conflicts and doc["event_type"] in {"COMPLETED", "JOB_FAILED"}]
        return {"state": "INCONSISTENT", "supporting_ids": support}
    return {"state": "RECORDED_HISTORY", "supporting_ids": []}


def unknown_interpretation():
    return "RECORDED_UNRESOLVED_OUTCOME"


def check_runtime_identity(identity, run_id):
    require(identity["run_id"] == run_id, "runtime run identity mismatch")
    require(identity["product_version"] == "3.9.0", "runtime version pin mismatch")
    require(identity["verified"] is True, "runtime resource verification missing")
    require(identity["pinned_reference"].startswith("opensearchproject/opensearch@sha256:"), "image not pinned")
