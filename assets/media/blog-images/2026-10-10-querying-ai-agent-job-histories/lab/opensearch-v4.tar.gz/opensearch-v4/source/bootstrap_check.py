"""Independent enforcement assertion for the frozen single-node topology."""

import argparse
import verifier as v


def environment(inspect):
    options = [entry for entry in inspect["Config"]["Env"] if entry.startswith("OPENSEARCH_JAVA_OPTS=")]
    v.equal(options, ["OPENSEARCH_JAVA_OPTS=-Xms1g -Xmx1g -Dopensearch.enforce.bootstrap.checks=true"], "single-node bootstrap checks must be explicitly enforced")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--inspect", required=True)
    args = parser.parse_args()
    environment(v.load(args.inspect))


if __name__ == "__main__":
    main()
