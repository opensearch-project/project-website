"""Trusted stdlib-only isolated entrypoint; verify every local byte before imports."""

import sys

if not (sys.flags.isolated and sys.flags.no_site and sys.flags.dont_write_bytecode):
    raise SystemExit('supported startup requires python3 -I -S -B')

import argparse
import hashlib
import json
import runpy
from pathlib import Path

ENTRIES = ('runtime', 'driver', 'offline_checks', 'os17_offline', 'os17_check', 'verify_cli', 'package_check', 'materialize_references', 'release_check')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def lexical_path(value):
    path = Path(value)
    require(path.is_absolute(), 'absolute lexical path required')
    require('..' not in path.parts, 'lexical parent traversal forbidden')
    for item in (path, *path.parents):
        require(not item.is_symlink(), 'package symlink or ancestor escape: ' + str(item))
    return path


def declared_path(package, relative):
    path = Path(relative)
    require(not path.is_absolute() and '..' not in path.parts, 'manifest path traversal')
    require(path.as_posix() == relative, 'noncanonical manifest path')
    target = lexical_path(str(package / path))
    require(target.is_file(), 'declared regular file missing: ' + relative)
    return target


def source_inventory(package):
    boundary = lexical_path(str(package / 'source'))
    require(boundary.is_dir(), 'source execution boundary missing')
    pending, files = [boundary], set()
    while pending:
        for path in pending.pop().iterdir():
            require(not path.is_symlink(), 'source inventory symlink')
            if path.is_dir():
                pending.append(path)
            else:
                require(path.is_file(), 'source inventory nonregular entry')
                files.add(path.relative_to(package).as_posix())
    return files


def verified_manifest(package, manifest, digest):
    require(manifest.is_relative_to(package), 'manifest outside package')
    require(len(digest) == 64 and all(letter in '0123456789abcdef' for letter in digest), 'external manifest SHA256 required')
    raw = manifest.read_bytes()
    require(hashlib.sha256(raw).hexdigest() == digest, 'externally pinned execution manifest changed')
    value = json.loads(raw)
    require(value['execution_boundary'] == 'source', 'exact source boundary required')
    declared = set(value['files'])
    source = {name for name in declared if Path(name).parts[0] == 'source'}
    require(source_inventory(package) == source, 'exact source inventory mismatch')
    require(set(value['non_source_artifacts']) == declared - source, 'explicit non-source inventory mismatch')
    for relative, expected in value['files'].items():
        target = declared_path(package, relative)
        require(hashlib.sha256(target.read_bytes()).hexdigest() == expected, 'frozen package bytes: ' + relative)
    return value


def prepare(args):
    launch = lexical_path(__file__)
    package = lexical_path(args.package)
    manifest = lexical_path(args.manifest)
    require(launch == package / 'source/trusted_bootstrap.py', 'bootstrap outside lexical package')
    value = verified_manifest(package, manifest, args.manifest_sha256)
    context = {'package': str(package), 'manifest': str(manifest), 'manifest_sha256': args.manifest_sha256, 'files': value['files']}
    sys._opensearch_verified_package = context
    sys.path.insert(0, str(package / 'source'))
    return context


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--package', required=True)
    parser.add_argument('--manifest', required=True)
    parser.add_argument('--manifest-sha256', required=True)
    parser.add_argument('--entry', choices=ENTRIES, required=True)
    parser.add_argument('arguments', nargs=argparse.REMAINDER)
    args = parser.parse_args()
    prepare(args)
    arguments = args.arguments
    if arguments[:1] == ['--']:
        arguments = arguments[1:]
    entry = Path(args.package) / 'source' / (args.entry + '.py')
    sys.argv = [str(entry), *arguments]
    runpy.run_path(str(entry), run_name='__main__')


if __name__ == '__main__':
    main()
