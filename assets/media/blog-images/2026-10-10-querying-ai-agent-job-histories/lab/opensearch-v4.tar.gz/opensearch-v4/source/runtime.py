"""Owned Linux runtime orchestration. No host changes or alternate topology."""

import sys

if not hasattr(sys, '_opensearch_verified_package'):
    raise SystemExit('use the pinned trusted bootstrap with python3 -I -S -B')

import argparse
import hashlib
import json
import os
import platform
import re
import time
import threading
from pathlib import Path

import host
import pin_check
import package_check
import bootstrap_check
import runtime_verifier as rv
import verifier as v
from transport import write_json


LAUNCH = Path(__file__).absolute()
PACKAGE = LAUNCH.parent.parent
package_check.no_symlink_ancestors(LAUNCH)
package_check.no_symlink_ancestors(PACKAGE)
v.equal(str(PACKAGE), sys._opensearch_verified_package['package'], 'verified lexical package launch')
GIB = 1024 ** 3
NETWORK_FORMAT = '{"id":{{json .Id}},"name":{{json .Name}},"mode":{{json .HostConfig.NetworkMode}},"networks":{{json .NetworkSettings.Networks}}}'
INSPECT_REPOSITORIES = {'library/python': 'python', 'opensearchproject/opensearch': 'opensearchproject/opensearch'}


class RuntimeFailures(RuntimeError):
    def __init__(self, errors):
        self.errors = tuple(errors)
        super().__init__('runtime and finalization failures: ' + '; '.join(f'{type(error).__name__}: {error}' for error in errors))


def familiar_digest(pin):
    """Bind the exact Docker Hub familiar name for each permitted official pin."""
    v.equal(pin['reference'], pin['repository'] + '@' + pin['platform_digest'], 'official pinned reference')
    return INSPECT_REPOSITORIES[pin['repository']] + '@' + pin['platform_digest']


def image_user(config):
    """Decode the optional ImageConfig User string with its empty default."""
    user = config.get('User', '')
    v.require(type(user) is str, 'ImageConfig.User must be a string')
    return user


def verify_image(package, pin, inspect):
    config = pin_check.registry_bytes(package, pin)
    v.equal(inspect['Id'], pin['platform_digest'], 'Docker containerd platform-manifest identity')
    v.equal(inspect['Architecture'], config['architecture'], 'local image architecture')
    v.equal(inspect['Os'], config['os'], 'local image OS')
    v.require(familiar_digest(pin) in inspect['RepoDigests'], 'immutable platform RepoDigest missing')
    v.equal(inspect['RootFS']['Layers'], config['rootfs']['diff_ids'], 'verified config rootfs identity')
    v.equal(image_user(inspect['Config']), image_user(config['config']), 'verified config image user')
    v.require(inspect['Size'] <= pin['projected_uncompressed_bytes'], 'uncompressed image exceeded estimate')


def source_hashes():
    paths = sorted((PACKAGE / "source").rglob("*")) + [PACKAGE / name for name in ("versions.lock.json", "REPRODUCE.md", "execution-manifest.json", "portable-allowlist.json", "settings-precedence-source.json", "fixture-expectations.json", "frozen-test-matrix.md", "amendments/os17/fixture-expectations.json", "amendments/os17/frozen-test-matrix.md", "amendments/os17/freeze.json", "amendments/os17/test-first.json")]
    pins = v.load(PACKAGE / "versions.lock.json")
    paths.extend(PACKAGE / relative for relative in pin_check.referenced_files(pins))
    return {str(path.relative_to(PACKAGE)): hashlib.sha256(path.read_bytes()).hexdigest() for path in paths if path.is_file() and "__pycache__" not in path.parts}


def pins_verified(pins):
    v.equal(pins["product_version"], "3.9.0", "product version")
    v.equal(pins["source_contracts_status"], "SOURCE_VERIFIED", "release-specific API source gate")
    for role in ("opensearch", "driver"):
        image = pins[role]
        expected = {"opensearch": ("opensearchproject/opensearch", "3.9.0"), "driver": ("library/python", "3.12.12-slim")}[role]
        v.equal((image["repository"], image["tag"]), expected, "official repository/version gate")
        v.equal(image["status"], "MANIFEST_VERIFIED", "official registry pin gate")
        for key in ("index_digest", "platform_digest", "config_digest"):
            v.require(re.fullmatch(r"sha256:[0-9a-f]{64}", image[key]) is not None, "invalid digest")
        v.equal(image["reference"], image["repository"] + "@" + image["platform_digest"], "digest reference")
        v.require(image["projected_uncompressed_bytes"] >= image["compressed_layer_bytes"], "image disk estimate missing")
    v.equal(pins["runtime_user"]["status"], "SOURCE_VERIFIED", "actual image UID/GID provenance gate")
    v.require(type(pins["runtime_user"]["uid"]) is int, "verified UID required")
    v.require(type(pins["runtime_user"]["gid"]) is int, "verified GID required")
    pin_check.verify(PACKAGE, pins)


def linux_required():
    v.equal(platform.system(), "Linux", "use only authorized Linux VM runtime")
    v.equal(platform.machine(), "x86_64", "Linux amd64 required")


class Runtime:
    def __init__(self, root, run_id, shared):
        linux_required()
        v.require(re.fullmatch(r"os-20261009-[a-z0-9]{4,16}", run_id) is not None, "invalid run ID")
        rv.owned_path(root)
        self.root = Path(root)
        self.run_id = run_id
        self.shared = v.load(shared)
        self.pins = v.load(PACKAGE / "versions.lock.json")
        pins_verified(self.pins)
        self.root.mkdir(mode=0o700)
        self.evidence = self.root / "runs" / run_id
        self.evidence.mkdir(parents=True)
        self.runner = host.Commands(self.evidence)
        self.owned = {"run_id": run_id, "root": str(self.root), "network": None, "containers": {}, "indexes": [run_id + "-os17-action-retry"], "source_hashes": source_hashes()}
        self.monitor = None
        self.logs_exported = False
        self.shutting_down = False
        self.sample_lock = threading.RLock()
        self.phases = {}
        self.persist_ownership()

    def persist_ownership(self):
        write_json(self.evidence / "ownership.json", self.owned)

    def preflight(self):
        info = self.runner.json(["docker", "info", "--format", '{"ServerVersion":{{json .ServerVersion}},"Architecture":{{json .Architecture}},"DockerRootDir":{{json .DockerRootDir}},"CgroupVersion":{{json .CgroupVersion}},"MemoryLimit":{{json .MemoryLimit}},"SwapLimit":{{json .SwapLimit}},"PidsLimit":{{json .PidsLimit}},"DriverStatus":{{json .DriverStatus}}}'], "docker-info")
        minimal_info = dict(info)
        write_json(self.evidence / "docker-info-minimal.json", minimal_info)
        v.equal(info['ServerVersion'], '29.1.3', 'pinned Docker release contract')
        v.require(['driver-type', 'io.containerd.snapshotter.v1'] in info['DriverStatus'], 'containerd image store required')
        v.equal(info["MemoryLimit"], True, "Docker memory enforcement")
        v.equal(info["SwapLimit"], True, "Docker swap enforcement")
        v.equal(info["PidsLimit"], True, "Docker PID enforcement")
        self.docker_root = info["DockerRootDir"]
        self.runner.call(["uname", "-a"], "uname")
        self.runner.call(["docker", "version", "--format", "{{json .Server}}"], "docker-version")
        self.unrelated_before = host.baseline(self.runner)
        self.collision_checks()
        state = host.sample(self.docker_root, self.evidence)
        rv.host(state, self.shared)
        cached = set(self.runner.call(["docker", "image", "ls", "--no-trunc", "--format", "{{.ID}}"], "cached-image-ids").splitlines())
        projected = projected_images(self.pins, cached)
        delta = rv.incremental_bytes(state, self.shared)
        v.require(delta + projected <= 8 * GIB, "projected combined image/lab disk budget")
        v.require(state["docker_disk"]["free_bytes"] - projected >= 25 * GIB, "projected minimum free disk")
        v.require((state["docker_disk"]["used_bytes"] + projected) / state["docker_disk"]["total_bytes"] < 0.94, "projected host use ratio")
        write_json(self.evidence / "preflight.json", {"sample": state, "projected_bytes": projected, "cached_pin_ids": sorted(cached & {self.pins[role]["platform_digest"] for role in ("opensearch", "driver")}), "shared_baseline": self.shared, "unrelated_baseline": self.unrelated_before})
        self.monitor = host.Monitor(self.runner, self.docker_root, self.evidence, self.shared, rv.host, self.sample_owned)
        self.monitor.thread.start()

    def sample_owned(self):
        with self.sample_lock:
            return self.sample_owned_locked()

    def sample_owned_locked(self):
        if self.shutting_down:
            return
        if not self.owned['containers']:
            return
        samples = {role: self.sample_role(role) for role in self.owned['containers']}
        record = {'gst': host.now(), 'owned_ids': list(self.owned['containers'].values()), 'roles': samples}
        with (self.evidence / "owned-resource-samples.jsonl").open("a") as file:
            file.write(json.dumps(record, sort_keys=True) + "\n")
        return record

    def sample_role(self, role):
        inspect = self.inspect_owned(role)
        phase = self.phases[role]
        state = inspect['State']
        if not state['Running']:
            self.inactive_state(role, phase, state)
            return {'id': inspect['Id'], 'phase': phase, 'state': state, 'stats': []}
        v.equal(state['Status'], 'running', 'known active owned state')
        container_id = inspect['Id']
        code, output, error_output = self.runner.call(['docker', 'stats', '--no-stream', '--format', '{{json .}}', container_id], 'owned-container-stats', 5, check=False)
        if code != 0:
            v.equal((role, phase), ('driver', 'completing'), 'active owned stats failure')
            v.equal((code, error_output.strip()), (1, 'EOF'), 'only recorded completion stats EOF is permitted')
            completed = self.inspect_owned(role)
            self.inactive_state(role, phase, completed['State'])
            v.equal(completed['State']['Status'], 'exited', 'stats failure requires proven driver completion')
            return {'id': container_id, 'phase': phase, 'state': completed['State'], 'stats': [], 'completion_stats_exit': code}
        stats = [json.loads(line) for line in output.splitlines()]
        v.equal(len(stats), 1, 'exact active owned resource sample')
        v.equal((stats[0]['ID'], stats[0]['Name']), (container_id[:12], self.run_id + '-' + role), 'exact owned stats identity')
        return {'id': container_id, 'phase': phase, 'state': state, 'stats': stats}

    def inactive_state(self, role, phase, state):
        v.equal(state['Running'], False, 'exact inactive owned state')
        expected = {'created': 'created', 'completing': 'exited'}
        v.require(phase in expected, 'active owned container unexpectedly stopped')
        v.equal(state['Status'], expected[phase], 'planned owned lifecycle state')
        v.equal(state['Pid'], 0, 'inactive owned PID')
        if phase == 'completing':
            v.equal(role, 'driver', 'only driver can finish before teardown')
            v.require(type(state['ExitCode']) is int, 'known driver completion exit')

    def collision_checks(self):
        names = self.runner.call(["docker", "ps", "-a", "--format", "{{.Names}}"], "name-collisions").splitlines()
        networks = self.runner.call(["docker", "network", "ls", "--format", "{{.Name}}"], "network-collisions").splitlines()
        for name in (self.run_id + "-opensearch", self.run_id + "-driver"):
            v.require(name not in names, "container name collision")
        v.require(self.run_id not in networks, "network name collision")

    def budget(self):
        self.monitor.ensure()
        rv.host(host.sample(self.docker_root, self.evidence), self.shared)

    def pull(self):
        for role in ("opensearch", "driver"):
            self.budget()
            pin = self.pins[role]
            self.runner.call(["docker", "pull", "--platform", "linux/amd64", pin["reference"]], "pull-" + role, 300)
            inspect = self.runner.json(["docker", "image", "inspect", pin["reference"]], "image-" + role)[0]
            verify_image(PACKAGE, pin, inspect)
            write_json(self.evidence / f"image-{role}.json", {"Id": inspect["Id"], "RepoDigests": inspect["RepoDigests"], "Size": inspect["Size"], "Architecture": inspect["Architecture"], "Os": inspect["Os"], "User": image_user(inspect["Config"]), "User_present": "User" in inspect["Config"], "RootFS": inspect['RootFS'], 'verified_config_digest': pin['config_digest'], 'store_contract': 'Docker29.1.3-containerd-platform-manifest'})

    def network(self):
        self.budget()
        network_id = self.runner.call(["docker", "network", "create", "--internal", "--label", "technical-blog-run=" + self.run_id, self.run_id], "create-network").strip()
        self.owned["network"] = {"id": network_id, "name": self.run_id}
        self.persist_ownership()

    def limits(self, role):
        values = {"opensearch": ("4g", "2", "512"), "driver": ("256m", "0.5", "128")}[role]
        return ["--memory", values[0], "--memory-swap", values[0], "--cpus", values[1], "--pids-limit", values[2], "--log-driver", "json-file", "--log-opt", "max-size=10m", "--log-opt", "max-file=3", "--label", "technical-blog-run=" + self.run_id, "--network", self.run_id, "--name", self.run_id + "-" + role]

    def create_container(self, role, options, command):
        self.budget()
        argv = ["docker", "create", *self.limits(role), *options, self.pins[role]["reference"], *command]
        container_id = self.runner.call(argv, "create-" + role).strip()
        with self.sample_lock:
            self.owned["containers"][role] = container_id
            self.phases[role] = 'created'
            self.persist_ownership()
        return container_id

    def authorize_owned(self, role):
        container_id = self.owned["containers"][role]
        inspect = self.runner.json(["docker", "inspect", container_id], "inspect-" + role)[0]
        v.equal(inspect["Id"], container_id, "exact owned container identity")
        v.equal(inspect["Name"], "/" + self.run_id + "-" + role, "exact owned container name")
        v.equal(inspect["Config"]["Labels"]["technical-blog-run"], self.run_id, "ownership label")
        return inspect

    def accept_owned(self, role, inspect):
        rv.container(inspect, self.owned["network"]["id"], self.pins[role]["platform_digest"], role)
        v.equal(inspect['Config']['Image'], self.pins[role]['reference'], 'container immutable create reference')
        if role == "opensearch":
            bootstrap_check.environment(inspect)

    def inspect_owned(self, role):
        inspect = self.authorize_owned(role)
        self.accept_owned(role, inspect)
        return inspect

    def start_opensearch(self):
        uid = self.pins["runtime_user"]["uid"]
        gid = self.pins["runtime_user"]["gid"]
        options = ["--network-alias", "opensearch", "--tmpfs", f"/usr/share/opensearch/data:rw,size=536870912,uid={uid},gid={gid},mode=0700", "--ulimit", "nofile=65536:65536", "--ulimit", "nproc=4096:4096", "-e", "discovery.type=single-node", "-e", "cluster.name=" + self.run_id, "-e", "DISABLE_INSTALL_DEMO_CONFIG=true", "-e", "DISABLE_SECURITY_PLUGIN=true", "-e", "OPENSEARCH_JAVA_OPTS=-Xms1g -Xmx1g -Dopensearch.enforce.bootstrap.checks=true"]
        container_id = self.create_container("opensearch", options, [])
        self.startup_deadline = time.monotonic() + 180
        with self.sample_lock:
            self.runner.call(["docker", "start", container_id], "start-opensearch")
            self.phases['opensearch'] = 'active'
            self.inspect_owned("opensearch")
        self.capture_mount(uid, gid)

    def capture_mount(self, uid, gid):
        container_id = self.owned["containers"]["opensearch"]
        actual_uid = int(self.runner.call(["docker", "exec", container_id, "id", "-u"], "runtime-uid"))
        actual_gid = int(self.runner.call(["docker", "exec", container_id, "id", "-g"], "runtime-gid"))
        output = self.runner.call(["docker", "exec", container_id, "df", "-T", "-B1", "/usr/share/opensearch/data"], "data-mount")
        fields = output.splitlines()[-1].split()
        ownership = self.runner.call(["docker", "exec", container_id, "stat", "-c", "%u:%g", "/usr/share/opensearch/data"], "data-owner").strip().split(":")
        identity = {"run_id": self.run_id, "product_version": "3.9.0", "pinned_reference": self.pins["opensearch"]["reference"], 'image_id': self.pins['opensearch']['platform_digest'], 'config_digest': self.pins['opensearch']['config_digest'], 'store_contract': 'Docker29.1.3-containerd-platform-manifest', "runtime_uid": uid, "runtime_gid": gid, "actual_uid": actual_uid, "actual_gid": actual_gid, "data_mount": {"type": fields[1], "capacity_bytes": int(fields[2]), "uid": int(ownership[0]), "gid": int(ownership[1])}}
        identity.update(product_container_id=container_id, configured_data_root='/usr/share/opensearch/data')
        identity['data_mount']['path'] = fields[-1]
        rv.opensearch_mount(identity)
        identity["verified"] = True
        write_json(self.evidence / "runtime-identity.json", identity)

    def run_driver(self):
        package_check.verify(PACKAGE, PACKAGE / "execution-manifest.json")
        options = self.driver_mounts()
        command = ["python3", "-I", "-S", "-B", "/package/source/trusted_bootstrap.py", "--package", "/package", "--manifest", "/package/execution-manifest.json", "--manifest-sha256", sys._opensearch_verified_package['manifest_sha256'], "--entry", "driver", "--", "--run-id", self.run_id, "--evidence", "/evidence", "--identity", "/evidence/runtime-identity.json", "--startup-deadline", str(self.startup_deadline)]
        container_id = self.create_container("driver", options, command)
        with self.sample_lock:
            self.runner.call(["docker", "start", container_id], "start-driver")
            self.phases['driver'] = 'completing'
            self.inspect_owned("driver")
        self.runner.call(["docker", "wait", container_id], "wait-driver", max(1, self.startup_deadline - time.monotonic()) + 600)
        inspect = self.inspect_owned("driver")
        v.equal(inspect["State"]["ExitCode"], 0, "driver process exit")
        self.monitor.ensure()
        v.equal(v.load(self.evidence / "results.json")["status"], "PASS", "suite result")

    def driver_mounts(self):
        context = sys._opensearch_verified_package
        v.equal(hashlib.sha256((PACKAGE / 'execution-manifest.json').read_bytes()).hexdigest(), context['manifest_sha256'], 'pre-mount external manifest pin')
        options = ["--user", f"{os.getuid()}:{os.getgid()}", "--cap-drop", "ALL", "--mount", f"type=bind,src={PACKAGE / 'source'},dst=/package/source,readonly", "--mount", f"type=bind,src={self.evidence},dst=/evidence", "--workdir", "/package", "-e", "PYTHONDONTWRITEBYTECODE=1"]
        paths = sorted(name for name in context['files'] if not name.startswith('source/'))
        for name in [*paths, 'execution-manifest.json']:
            options.extend(['--mount', f'type=bind,src={PACKAGE / name},dst=/package/{name},readonly'])
        return options

    def export(self):
        self.capture_logs()
        before = self.owned["source_hashes"]
        after = source_hashes()
        v.equal(after, before, "final bytes changed during live run")
        summary = {"run_id": self.run_id, "network_id": self.owned["network"]["id"], "main_index": self.run_id + "-main", "os17_index": self.run_id + "-os17-action-retry", "source_hashes": after, "pins": self.pins, "suite_status": "PASS", "semantics": semantic_results(self.evidence)}
        write_json(self.evidence / "run-binding.json", summary)
        write_json(self.evidence / "source-before-after.json", {"before": before, "after": after, "equal": True})

    def capture_logs(self):
        if self.logs_exported:
            return
        for role, container_id in self.owned["containers"].items():
            self.runner.call(["docker", "logs", container_id], "logs-" + role)
        self.logs_exported = True

    def cleanup(self):
        with self.sample_lock:
            final_sample = self.sample_owned_locked()
            write_json(self.evidence / 'owned-final-sample.json', final_sample)
            self.shutting_down = True
        report = {"errors": [], "inspects": [], "removed_container_ids": [], "removed_network": None, "unrelated_before": self.unrelated_before, "unrelated_after": None}
        self.cleanup_report = report
        for role in self.owned["containers"]:
            self.cleanup_container(role, report)
        self.cleanup_network(report)
        self.cleanup_checks(report)
        report["residual_container_ids"] = sorted(set(self.owned["containers"].values()) - set(report["removed_container_ids"]))
        report["residual_network"] = self.owned["network"] if report["removed_network"] is None else None
        report["residuals"] = ["digest-pinned image layers retained", str(self.root)]
        report["status"] = "FAIL" if report["errors"] else "PASS"
        self.persist_cleanup(report)

    def persist_cleanup(self, report):
        errors = list(report["errors"])
        cause = None
        operations = [(write_json, (self.evidence / "cleanup.json", report)), (self.cleanup_results, (report,))]
        for operation, arguments in operations:
            try:
                operation(*arguments)
            except Exception as error:
                errors.append(f"cleanup persistence: {type(error).__name__}: {error}")
                cause = error
        if errors:
            raise RuntimeError("; ".join(errors)) from cause

    def cleanup_container(self, role, report):
        container_id = self.owned["containers"][role]
        try:
            self.dependency_guard(report)
            inspect = self.authorize_owned(role)
            report["inspects"].append(inspect)
        except Exception as error:
            cleanup_error(report, "identity-" + role, error)
            return
        try:
            self.accept_owned(role, inspect)
        except Exception as error:
            cleanup_error(report, "acceptance-" + role, error)
            return
        try:
            self.runner.call(["docker", "stop", "--time", "10", container_id], "stop-" + role, 30)
            self.runner.call(["docker", "rm", container_id], "remove-" + role)
            report["removed_container_ids"].append(container_id)
        except Exception as error:
            cleanup_error(report, "teardown-" + role, error)

    def cleanup_network(self, report):
        if self.owned["network"] is None:
            return
        network_id = self.owned["network"]["id"]
        try:
            self.dependency_guard(report)
            inspected = self.runner.json(["docker", "network", "inspect", network_id], "inspect-network")[0]
            v.equal(inspected["Id"], network_id, "exact owned network identity")
            v.equal(inspected["Name"], self.owned["network"]["name"], "exact owned network name")
            v.equal(inspected["Labels"]["technical-blog-run"], self.run_id, "network ownership")
            self.runner.call(["docker", "network", "rm", network_id], "remove-network")
            report["removed_network"] = self.owned["network"]
        except Exception as error:
            cleanup_error(report, "network", error)

    def dependency_guard(self, report):
        ids = self.runner.call(['docker', 'ps', '-aq', '--no-trunc'], 'dependency-inventory').splitlines()
        v.equal(len(ids), len(set(ids)), 'unique all-container inventory')
        records = []
        if ids:
            raw = self.runner.call(['docker', 'inspect', '--format', NETWORK_FORMAT, *ids], 'dependency-records')
            records = [json.loads(line) for line in raw.splitlines()]
        v.equal(len(records), len(ids), 'complete constrained network inventory')
        v.equal({item['id'] for item in records}, set(ids), 'exact network inventory IDs')
        allowed = set(self.owned['containers'].values()) - set(report['removed_container_ids'])
        network = {'Id': self.owned['network']['id'], 'Name': self.owned['network']['name']}
        validate_dependencies(records, network, allowed)
        actual = self.runner.json(['docker', 'network', 'inspect', network['Id']], 'inspect-network')[0]
        v.equal((actual['Id'], actual['Name']), (network['Id'], network['Name']), 'exact cleanup network identity')
        v.equal(actual['Labels']['technical-blog-run'], self.run_id, 'exact cleanup network ownership')
        v.equal(actual['Internal'], True, 'internal cleanup network')
        v.require(set(actual['Containers']) <= allowed, 'unknown cleanup network endpoint')

    def cleanup_checks(self, report):
        try:
            rv.shutdown(report["inspects"], report["removed_container_ids"], self.owned["containers"].values())
        except Exception as error:
            cleanup_error(report, "shutdown-acceptance", error)
        try:
            report["unrelated_after"] = host.baseline(self.runner)
            rv.unchanged_unrelated(self.unrelated_before, report["unrelated_after"])
        except Exception as error:
            cleanup_error(report, "unrelated-baseline", error)

    def cleanup_results(self, report):
        if (self.evidence / "run-binding.json").exists():
            results = v.load(self.evidence / "results.json")
            results["cases"].extend([{"id": "OS16", "status": report["status"], "evidence": "cleanup.json, resource-samples.jsonl, source-before-after.json"}, {"id": "OS15", "status": "NOT_RUN", "gate": "second fresh run and verify-replay required"}])
            results["status"] = "FAIL" if report["errors"] else "BLOCKED"
            write_json(self.evidence / "results.json", results)

    def launch(self):
        errors = []
        self.launch_errors = errors
        try:
            self.preflight()
            self.pull()
            self.network()
            self.start_opensearch()
            self.run_driver()
            self.export()
        except Exception as error:
            errors.append(error)
            try:
                write_json(self.evidence / "runtime-failure.json", {"status": "FAIL", "error": f"{type(error).__name__}: {error}"})
            except Exception as persistence:
                errors.append(persistence)
        try:
            self.finalize()
        except Exception as error:
            errors.append(error)
        if errors:
            raise RuntimeFailures(errors) from errors[0]

    def finalize(self):
        errors = [f'original runtime failure: {type(error).__name__}: {error}' for error in getattr(self, 'launch_errors', [])]
        cause = None
        try:
            (self.evidence / 'finalization-success.json').unlink(missing_ok=True)
        except Exception as error:
            errors.append(f'receipt invalidation: {type(error).__name__}: {error}')
        operations = [self.capture_logs]
        if hasattr(self, "unrelated_before"):
            operations.append(self.cleanup)
        if self.monitor is not None:
            operations.append(self.stop_monitor)
        for operation in operations:
            try:
                operation()
            except Exception as error:
                errors.append(f"{operation.__name__}: {type(error).__name__}: {error}")
                cause = error
        if errors:
            self.finalization_failed(errors, cause)
        self.finalization_success()

    def stop_monitor(self):
        self.monitor.stop()
        v.require(not self.monitor.thread.is_alive(), 'monitor thread still alive after stop deadline')
        self.monitor_stopped = True

    def finalization_failed(self, errors, cause=None):
        self.finalization_errors = errors
        try:
            write_json(self.evidence / "finalization-failure.json", {"status": "FAIL", "errors": errors})
        except Exception as error:
            errors.append(f'finalization diagnostics: {type(error).__name__}: {error}')
        raise RuntimeError('; '.join(errors)) from cause

    def finalization_success(self):
        v.require(self.monitor is not None, 'successful monitor stop required')
        v.equal(self.monitor_stopped, True, 'proven monitor stop required')
        report = self.cleanup_report
        v.equal(report['status'], 'PASS', 'positive owned cleanup required')
        v.equal(report['residual_container_ids'], [], 'owned container residuals')
        v.equal(report['residual_network'], None, 'owned network residual')
        binding = self.evidence / 'run-binding.json'
        v.equal(v.load(binding)['suite_status'], 'PASS', 'positive suite binding required')
        receipt = {'status': 'PASS', 'run_id': v.load(binding)['run_id'], 'monitor_stopped': True, 'cleanup_proven': True, 'run_binding_sha256': hashlib.sha256(binding.read_bytes()).hexdigest(), 'cleanup_sha256': hashlib.sha256((self.evidence / 'cleanup.json').read_bytes()).hexdigest()}
        pending = self.evidence / 'finalization-success.pending.json'
        write_json(pending, receipt)
        pending.replace(self.evidence / 'finalization-success.json')


def cleanup_error(report, stage, error):
    report["errors"].append(f"{stage}: {type(error).__name__}: {error}")


def references_network(record, network):
    v.equal(set(record), {'id', 'name', 'mode', 'networks'}, 'constrained dependency fields')
    v.require(re.fullmatch(r'[0-9a-f]{64}', record['id']) is not None, 'full container ID')
    v.require(isinstance(record['name'], str) and record['name'].startswith('/'), 'known container name')
    v.require(isinstance(record['mode'], str) and bool(record['mode']), 'known network mode')
    v.require(isinstance(record['networks'], dict), 'known configured networks')
    found = record['mode'] in {network['Name'], network['Id']}
    for name, attachment in record['networks'].items():
        v.require(isinstance(name, str) and bool(name), 'known network name')
        identifier = attachment['NetworkID']
        v.require(isinstance(identifier, str) and bool(identifier), 'known network ID')
        if name == network['Name'] or identifier == network['Id']:
            v.equal((name, identifier), (network['Name'], network['Id']), 'exact configured network reference')
            found = True
    return found


def namespace_target(record, records):
    if not record['mode'].startswith('container:'):
        return None
    target = record['mode'].removeprefix('container:')
    v.require(bool(target), 'known namespace target')
    matches = {item['id'] for item in records if item['id'].startswith(target) or item['name'].removeprefix('/') == target.removeprefix('/')}
    v.equal(len(matches), 1, 'unique namespace target')
    return matches.pop()


def namespace_references(identifier, targets, members):
    visited = set()
    found = False
    while identifier is not None:
        v.require(identifier not in visited, 'acyclic namespace dependencies')
        visited.add(identifier)
        found = found or identifier in members
        identifier = targets[identifier]
    return found


def validate_dependencies(records, network, allowed):
    v.equal(len(records), len({item['id'] for item in records}), 'unique dependency IDs')
    members = {item['id'] for item in records if references_network(item, network)}
    targets = {item['id']: namespace_target(item, records) for item in records}
    v.equal(members, allowed, 'only proven owned configured network members')
    dependents = {identifier for identifier in targets if namespace_references(identifier, targets, members)}
    v.equal(dependents, allowed, 'only proven owned namespace dependents')


def semantic_results(evidence):
    results = {}
    for query_id in ("Q01", "Q02", "Q03", "Q04", "Q05", "Q06"):
        record = v.load(evidence / "queries" / query_id / "record.json")
        results[query_id] = {"responses": [semantic_response(response) for response in record["responses"]], "presentation": record.get("presentation"), "expected": v.load(evidence / "queries" / query_id / "expected.json")}
    v.equal(v.load(evidence / "OS17" / "cleanup.json")["status"], "PASS", "OS17 index cleanup")
    results["OS17"] = v.load(evidence / "OS17" / "comparison.json")["observed"]
    return results


def projected_images(pins, cached_ids):
    projected = 0
    for role in ("opensearch", "driver"):
        image = pins[role]
        if image["platform_digest"] not in cached_ids:
            projected += image["projected_uncompressed_bytes"] + image["compressed_layer_bytes"]
    return projected


def semantic_response(response):
    value = {"total": response["hits"]["total"], "hits": [{"id": hit["_id"], "source": hit["_source"]} for hit in response["hits"]["hits"]]}
    if "aggregations" in response:
        value["buckets"] = response["aggregations"]["attempts"]["buckets"]
    return value


def preflight_only(args):
    linux_required()
    v.require(Path(args.root).is_dir(), "read-only preflight root must exist")
    output = host.Commands(Path(args.root) / "preflight-evidence")
    info = output.json(["docker", "info", "--format", "{{json .DockerRootDir}}"], "docker-root")
    state = host.sample(info, Path(args.root))
    write_json(Path(args.root) / "preflight.json", state)
    rv.host(state, v.load(args.shared_baseline))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("operation", choices=("preflight", "launch", "verify-replay"))
    parser.add_argument("--root")
    parser.add_argument("--run-id")
    parser.add_argument("--shared-baseline")
    parser.add_argument("--execute-authorized", action="store_true")
    parser.add_argument("--first")
    parser.add_argument("--second")
    parser.add_argument("--output")
    args = parser.parse_args()
    handlers = {"preflight": preflight_only, "launch": launch_authorized, "verify-replay": verify_replay}
    handlers[args.operation](args)


def launch_authorized(args):
    v.require(args.execute_authorized, "coordinator runtime authorization required")
    package_check.verify(PACKAGE, PACKAGE / "execution-manifest.json")
    Runtime(args.root, args.run_id, args.shared_baseline).launch()


def verify_replay(args):
    first = v.load(args.first)
    second = v.load(args.second)
    for path in (args.first, args.second):
        v.equal(v.load(Path(path).with_name("cleanup.json"))["status"], "PASS", "OS16 cleanup gate")
        v.require(not Path(path).with_name("finalization-failure.json").exists(), "failed finalization")
        finalization_receipt(Path(path))
    rv.repeatability(first, second)
    write_json(args.output, {"id": "OS15", "status": "PASS", "first": args.first, "second": args.second, "source_hashes": first["source_hashes"]})


def finalization_receipt(binding):
    receipt = v.load(binding.with_name('finalization-success.json'))
    v.equal(receipt['status'], 'PASS', 'positive finalization success required')
    v.equal(receipt['monitor_stopped'], True, 'monitor stop receipt')
    v.equal(receipt['cleanup_proven'], True, 'owned cleanup receipt')
    v.equal(receipt['run_id'], v.load(binding)['run_id'], 'finalization run identity')
    v.equal(receipt['run_binding_sha256'], hashlib.sha256(binding.read_bytes()).hexdigest(), 'finalization binding bytes')
    v.equal(receipt['cleanup_sha256'], hashlib.sha256(binding.with_name('cleanup.json').read_bytes()).hexdigest(), 'finalization cleanup bytes')


if __name__ == "__main__":
    main()
