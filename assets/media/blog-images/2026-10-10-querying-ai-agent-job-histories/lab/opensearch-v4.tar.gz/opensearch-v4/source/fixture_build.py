"""Deterministic synthetic authoring; never used by the independent oracle."""

import json
from datetime import datetime, timedelta
from pathlib import Path

from application import ACTION_TYPES, document_hash, sanitize_batch


ORDER = [
    ["alpha", "job-ok", 1, 1, "STARTED"],
    ["beta", "job-ok", 3, 1, "COMPUTE_FINISHED"],
    ["alpha", "job-retry", 4, 2, "STARTED"],
    ["alpha", "job-late", 1, 1, "STARTED"],
    ["alpha", "job-unknown", 5, 1, "HOLD_UNKNOWN"],
    ["alpha", "job-ok", 5, 1, "ACTION_CONFIRMED"],
    ["alpha", "job-retry", 1, 1, "STARTED"],
    ["beta", "job-ok", 6, 1, "COMPLETED"],
    ["alpha", "job-late", 6, 1, "COMPLETED"],
    ["alpha", "job-retry", 9, 2, "COMPLETED"],
    ["alpha", "job-ok", 4, 1, "ACTION_REQUESTED"],
    ["alpha", "job-unknown", 2, 1, "COMPUTE_STARTED"],
    ["beta", "job-ok", 1, 1, "STARTED"],
    ["alpha", "job-retry", 3, 1, "COMPUTE_FAILED"],
    ["alpha", "job-ok", 6, 1, "COMPLETED"],
    ["alpha", "job-late", 4, 1, "ACTION_REQUESTED"],
    ["alpha", "job-retry", 7, 2, "ACTION_REQUESTED"],
    ["beta", "job-ok", 4, 1, "ACTION_REQUESTED"],
    ["alpha", "job-unknown", 1, 1, "STARTED"],
    ["alpha", "job-late", 2, 1, "COMPUTE_STARTED"],
    ["alpha", "job-retry", 6, 2, "COMPUTE_FINISHED"],
    ["alpha", "job-ok", 2, 1, "COMPUTE_STARTED"],
    ["beta", "job-ok", 5, 1, "ACTION_CONFIRMED"],
    ["alpha", "job-unknown", 4, 1, "ACTION_REQUESTED"],
    ["alpha", "job-retry", 8, 2, "ACTION_CONFIRMED"],
    ["alpha", "job-late", 5, 1, "ACTION_CONFIRMED"],
    ["alpha", "job-ok", 3, 1, "COMPUTE_FINISHED"],
    ["alpha", "job-retry", 2, 1, "COMPUTE_STARTED"],
    ["beta", "job-ok", 2, 1, "COMPUTE_STARTED"],
    ["alpha", "job-unknown", 3, 1, "COMPUTE_FINISHED"],
    ["alpha", "job-retry", 5, 2, "COMPUTE_STARTED"],
    ["alpha", "job-late", 3, 1, "COMPUTE_FINISHED"],
    ["alpha", "job-late", 7, 1, "JOB_FAILED"]
]
ORIGIN = datetime.fromisoformat("2026-10-01T12:00:00.000+04:00")


def at(seconds):
    return (ORIGIN + timedelta(seconds=seconds)).isoformat(timespec="milliseconds")


def event(row):
    tenant, job, sequence, attempt, event_type = row
    event_seconds = sequence
    ingestion_seconds = 100 + sequence
    if (tenant, job, sequence) == ("alpha", "job-ok", 5):
        event_seconds, ingestion_seconds = 4, 104
    if (tenant, job, sequence) == ("alpha", "job-late", 7):
        event_seconds, ingestion_seconds = 2, 200
    doc = {"schema_version": 1, "tenant_id": tenant, "job_id": job, "event_id": f"{tenant}:{job}:a{attempt}:s{sequence:02d}", "event_type": event_type, "attempt": attempt, "sequence": sequence, "event_time": at(event_seconds), "ingested_at": at(ingestion_seconds)}
    if event_type in ACTION_TYPES:
        doc["action_id"] = f"{tenant}:{job}:followup:v1"
    return doc


def main():
    root = Path(__file__).parent
    docs = sanitize_batch([event(row) for row in ORDER])
    (root / "fixtures.json").write_text(json.dumps(docs, indent=2) + "\n")
    manifest = {"origin_gst": "2026-10-01 12:00:00 GST", "synthetic": True, "timestamps_are_authored": True, "initial_order": [doc["event_id"] for doc in docs[:-1]], "separate_late_order": [docs[-1]["event_id"]], "canonical_sanitized_sha256": {doc["event_id"]: document_hash(doc) for doc in docs}}
    (root / "fixture-manifest.json").write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n")


if __name__ == "__main__":
    main()
