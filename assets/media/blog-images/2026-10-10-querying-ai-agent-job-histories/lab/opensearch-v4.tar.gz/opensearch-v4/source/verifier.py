"""Independent result checks; the literal oracle never imports application code."""

import json
import re
from pathlib import Path


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def equal(actual, expected, message):
    require(actual == expected, f"{message}: actual={actual!r}, expected={expected!r}")


def load(path):
    return json.loads(Path(path).read_text())


def search_complete(body, total):
    equal(body["timed_out"], False, "search timed out")
    equal(body["_shards"]["failed"], 0, "failed shards")
    equal(body["_shards"]["successful"], body["_shards"]["total"], "partial shards")
    equal(body["hits"]["total"], {"value": total, "relation": "eq"}, "exact total")


def ids(body):
    return [hit["_id"] for hit in body["hits"]["hits"]]


def sources(body):
    return [hit["_source"] for hit in body["hits"]["hits"]]


def history(body, expected):
    search_complete(body, len(expected))
    equal(ids(body), expected, "complete ordered history")
    for hit in body["hits"]["hits"]:
        equal(hit["_id"], hit["_source"]["event_id"], "source/ID binding")


def fixture_sources(docs, oracle):
    for doc in docs:
        job = doc["tenant_id"] + "/" + doc["job_id"]
        position = oracle["histories"][job].index(doc["event_id"])
        equal(doc["event_type"], oracle["event_types"][job][position], "literal event type")
        equal(doc["sequence"], position + 1, "literal inventory sequence")
        schema(doc)


def disk_guards(settings):
    effective = {}
    for layer in ("defaults", "persistent", "transient"):
        effective.update(settings[layer])
    prefix = "cluster.routing.allocation.disk."
    equal(str(effective[prefix + "threshold_enabled"]).lower(), "true", "disk guard disabled")
    for name, expected in (("low", "85%"), ("high", "90%"), ("flood_stage", "95%")):
        equal(effective[prefix + "watermark." + name], expected, "disk default changed")


def node_filesystem(response, identity):
    equal(response["_nodes"]["failed"], 0, "filesystem node failure")
    equal(len(response["nodes"]), 1, "single-node filesystem")
    equal(response['cluster_name'], identity['run_id'], 'filesystem exact cluster identity')
    equal(identity['configured_data_root'], '/usr/share/opensearch/data', 'configured data root')
    require(re.fullmatch('[0-9a-f]{64}', identity['product_container_id']) is not None, 'full product container identity')
    node = next(iter(response['nodes'].values()))
    equal(node['name'], identity['product_container_id'][:12], 'filesystem exact product node name')
    entries = [entry for node in response["nodes"].values() for entry in node["fs"]["data"]]
    equal(len(entries), 1, "single data path")
    equal(entries[0]["path"], "/usr/share/opensearch/data/nodes/0", "exact fresh node data path")
    equal(entries[0]['mount'], '/usr/share/opensearch/data (tmpfs)', 'exact configured data mount')
    equal(entries[0]["type"], "tmpfs", "effective filesystem type")
    equal(entries[0]["total_in_bytes"], 536870912, "effective data capacity")


def jvm_heap(response):
    equal(response["_nodes"]["failed"], 0, "JVM node failure")
    equal(len(response["nodes"]), 1, "single-node JVM")
    for node in response["nodes"].values():
        equal(node["jvm"]["mem"]["heap_init_in_bytes"], 1073741824, "initial heap")
        equal(node["jvm"]["mem"]["heap_max_in_bytes"], 1073741824, "maximum heap")


def query01(pages, oracle):
    equal([len(page["hits"]["hits"]) for page in pages], oracle["page_lengths"], "pages")
    for page in pages:
        search_complete(page, oracle["total"])
    hits = [hit for page in pages for hit in page["hits"]["hits"]]
    equal([hit["_id"] for hit in hits], oracle["ids"], "pagination IDs")
    equal([hit["_source"]["attempt"] for hit in hits], oracle["attempts"], "attempts")
    equal(len(set(oracle["ids"])), len(hits), "duplicates")


def query02(pages, oracle, presented):
    for page in pages:
        search_complete(page, oracle["total"])
    buckets = [bucket for page in pages for bucket in page["aggregations"]["attempts"]["buckets"]]
    equal(buckets, oracle["buckets"], "composite buckets")
    require(len(pages) >= 3, "composite pagination omitted")
    require(all(len(page["aggregations"]["attempts"]["buckets"]) <= 2 for page in pages), "composite size")
    equal(presented, oracle["retry_jobs"], "retry presentation")


def query04(body, oracle, interpretation):
    history(body, oracle["ids"])
    equal([doc["action_id"] for doc in sources(body)], oracle["actions"], "stable action")
    equal(interpretation, oracle["interpretation"], "unknown interpretation")


def query05(before, after, oracle, interpretation):
    history(before, oracle["before_ids"])
    history(after, oracle["after_ids"])
    equal(interpretation, {"state": oracle["interpretation"], "supporting_ids": oracle["supporting_ids"]}, "contradiction")
    newest = max(sources(after), key=ingested_time)
    equal(newest["event_id"], oracle["newest_ingested_id"], "naive newest event")


def ingested_time(doc):
    return doc["ingested_at"]


def bulk(body, expected_ids, statuses, error_types):
    equal(body["errors"], any(status >= 400 for status in statuses), "bulk error flag")
    equal(len(body["items"]), len(statuses), "bulk item count")
    for item, event_id, status, category in zip(body["items"], expected_ids, statuses, error_types):
        equal(set(item), {"create"}, "bulk operation")
        result = item["create"]
        equal(result["_id"], event_id, "bulk ordered ID")
        equal(result["status"], status, "bulk ordered status")
        if category is not None:
            equal(result["error"]["type"], category, "bulk error category")


def redacted(payload, markers, allowed):
    text = json.dumps(payload, sort_keys=True)
    for marker in markers:
        require(marker not in text, f"redaction marker retained: {marker}")
    require(set(payload) <= set(allowed), "unlisted field retained")


def schema(payload):
    required = {"schema_version", "tenant_id", "job_id", "event_id", "event_type", "attempt", "sequence", "event_time", "ingested_at"}
    require(required <= set(payload), "required field missing")
    require(set(payload) <= required | {"action_id"}, "unlisted field retained")
    for field in ("schema_version", "attempt", "sequence"):
        require(type(payload[field]) is int, "integer type violation")
        require(payload[field] > 0, "positive integer violation")
    equal(payload["schema_version"], 1, "schema version")
    for field in required - {"schema_version", "attempt", "sequence"}:
        require(type(payload[field]) is str, "string type violation")


def tenant_request(request, tenant):
    terms = request["query"]["bool"]["filter"]
    require({"term": {"tenant_id": tenant}} in terms, "tenant filter missing")
    equal(request["track_total_hits"], True, "exact hits required")


def rejects(function, *args):
    try:
        function(*args)
    except (AssertionError, ValueError, KeyError, TypeError):
        return
    raise AssertionError("negative control accepted invalid input")
