"""Fetch only lock-bound official reference files; no product or image pull."""

import argparse
import hashlib
from pathlib import Path
import release_check
import verifier as v


def retain(root, relative, url, digest):
    target = root / relative
    v.require(not target.exists(), "reference destination must be fresh: " + relative)
    raw, _ = release_check.fetch(url, root / "references" / "materialization", hashlib.sha256(url.encode()).hexdigest())
    v.equal(hashlib.sha256(raw).hexdigest(), digest, "immutable reference bytes")
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(raw)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--package", required=True)
    args = parser.parse_args()
    root = Path(args.package).resolve()
    pins = v.load(root / "versions.lock.json")
    for claim in pins["source_contracts"]:
        retain(root, claim["artifact"], claim["url"], claim["sha256"])
    user = pins["runtime_user"]
    retain(root, user["source_artifact"], user["source_url"], user["source_sha256"])


if __name__ == "__main__":
    main()
