"""Linux read-only preflight, resource sampling and captured subprocess execution."""

import json
import os
import platform
import resource
import subprocess
import threading
import time
from pathlib import Path

from transport import now, write_json


def disk(path):
    stat = os.statvfs(path)
    total = stat.f_blocks * stat.f_frsize
    used = (stat.f_blocks - stat.f_bfree) * stat.f_frsize
    return {"path": str(path), "device": os.stat(path).st_dev, "total_bytes": total, "used_bytes": used, "free_bytes": stat.f_bavail * stat.f_frsize, "used_ratio": used / total, "free_inodes": stat.f_favail}


def memory_available():
    entries = dict(line.split(":", 1) for line in Path("/proc/meminfo").read_text().splitlines())
    return int(entries["MemAvailable"].split()[0]) * 1024


def tree_bytes(root):
    return sum(path.stat().st_size for path in Path(root).rglob("*") if path.is_file())


def hard_limit(key):
    value = resource.getrlimit(key)[1]
    return 2 ** 63 - 1 if value == resource.RLIM_INFINITY else value


def sample(docker_root, evidence_root):
    controllers = set(Path("/sys/fs/cgroup/cgroup.controllers").read_text().split())
    return {"gst": now(), "architecture": platform.machine(), "vm_max_map_count": int(Path("/proc/sys/vm/max_map_count").read_text()), "memory_available_bytes": memory_available(), "docker_disk": disk(docker_root), "owned_root_disk": disk(evidence_root), "evidence_bytes": tree_bytes(evidence_root), "nofile_hard": hard_limit(resource.RLIMIT_NOFILE), "nproc_hard": hard_limit(resource.RLIMIT_NPROC), "cgroup_memory_limit_supported": "memory" in controllers, "cgroup_pids_supported": "pids" in controllers, "cgroup_cpu_limit_supported": "cpu" in controllers}


def baseline(runner):
    output = runner.call(["docker", "ps", "-a", "--no-trunc", "--format", "{{json .ID}} {{json .State}}"], "container-baseline")
    return parse_baseline(output)


def parse_baseline(output):
    records = {}
    for line in output.splitlines():
        container_id, state = line.split()
        records[json.loads(container_id)] = json.loads(state)
    return records


class Commands:
    def __init__(self, evidence):
        self.evidence = Path(evidence)
        self.evidence.mkdir(parents=True, exist_ok=True)
        self.active = []
        self.lock = threading.Lock()
        self.counter = 0

    def call(self, argv, name, timeout=15, check=True):
        with self.lock:
            self.counter += 1
            prefix = f"host-{self.counter:04d}-{name}"
        stdout = self.evidence / f"{prefix}.stdout"
        stderr = self.evidence / f"{prefix}.stderr"
        record = {"argv": argv, "cwd": str(Path.cwd()), "start_gst": now(), "timeout_seconds": timeout, "stdout": stdout.name, "stderr": stderr.name}
        process = None
        try:
            with stdout.open("wb") as out, stderr.open("wb") as err:
                process = subprocess.Popen(argv, stdout=out, stderr=err, stdin=subprocess.DEVNULL)
                self.active.append(process)
                code = process.wait(timeout=timeout)
            record["exit"] = code
            if code != 0 and check:
                raise RuntimeError(f"{name} exit {code}; stderr retained at {stderr}")
            if not check:
                return code, stdout.read_text(), stderr.read_text()
            return stdout.read_text()
        except subprocess.TimeoutExpired:
            process.kill()
            record["exit"] = process.wait()
            record["error"] = "timeout"
            raise
        finally:
            record["end_gst"] = now()
            self.record(record)
            if process in self.active:
                self.active.remove(process)

    def record(self, record):
        with self.lock:
            with (self.evidence / "commands.jsonl").open("a") as file:
                file.write(json.dumps(record, sort_keys=True) + "\n")

    def json(self, argv, name):
        return json.loads(self.call(argv, name))

    def stop_active(self):
        for process in list(self.active):
            if process.poll() is None:
                process.terminate()


class Monitor:
    def __init__(self, runner, docker_root, evidence, shared, check, sample_owned):
        self.runner = runner
        self.docker_root = docker_root
        self.evidence = Path(evidence)
        self.shared = shared
        self.check = check
        self.sample_owned = sample_owned
        self.error = None
        self.event = threading.Event()
        self.thread = threading.Thread(target=self.run, daemon=True)

    def take(self):
        value = sample(self.docker_root, self.evidence)
        with (self.evidence / "resource-samples.jsonl").open("a") as file:
            file.write(json.dumps(value, sort_keys=True) + "\n")
        self.check(value, self.shared, 2 * 1024 ** 3)
        self.sample_owned()

    def run(self):
        next_sample = time.monotonic()
        while not self.event.is_set():
            try:
                self.take()
            except Exception as error:
                self.abort_failure(error)
                return
            next_sample += 5
            self.event.wait(max(0, next_sample - time.monotonic()))

    def abort_failure(self, error):
        failures = [f"{type(error).__name__}: {error}"]
        self.failure = {"errors": failures}
        self.error = "; ".join(failures)
        try:
            self.runner.stop_active()
        except Exception as abort_error:
            failures.append(f"abort: {type(abort_error).__name__}: {abort_error}")
        self.error = "; ".join(failures)
        try:
            write_json(self.evidence / "budget-failure.json", {"error": self.error, "errors": failures})
        except Exception as write_error:
            failures.append(f"diagnostic persistence: {type(write_error).__name__}: {write_error}")
        self.error = "; ".join(failures)

    def ensure(self):
        if self.error is not None:
            raise RuntimeError(self.error)

    def stop(self):
        self.event.set()
        self.thread.join(timeout=10)
        self.ensure()
