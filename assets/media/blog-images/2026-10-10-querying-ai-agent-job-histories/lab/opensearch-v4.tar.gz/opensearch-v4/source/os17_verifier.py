"""Independent literal OS17 assertions. No loader, generator or reducer imports."""

import json
import verifier as v


REQUEST = {"size": 3, "track_total_hits": True, "query": {"bool": {"filter": [{"term": {"tenant_id": "alpha"}}, {"term": {"job_id": "job-action-retry"}}]}}, "sort": [{"sequence": "asc"}, {"event_id": "asc"}]}
CURSORS = [None, [3, "alpha:job-action-retry:a1:s03"], [6, "alpha:job-action-retry:a2:s06"], [8, "alpha:job-action-retry:a2:s08"]]
LENGTHS = [3, 3, 2, 0]
LABEL = "RECORDED_CONFIRMATION_BEFORE_RESTART"


def typed_equal(actual, expected, label):
    v.equal(type(actual), type(expected), label + " type")
    if isinstance(expected, dict):
        v.equal(set(actual), set(expected), label + " keys")
        for key, value in expected.items():
            typed_equal(actual[key], value, label + "." + key)
    elif isinstance(expected, list):
        v.equal(len(actual), len(expected), label + " length")
        for position, value in enumerate(expected):
            typed_equal(actual[position], value, label + " item")
    else:
        v.equal(actual, expected, label)


def page_complete(page):
    typed_equal(page["status"], 200, "HTTP status")
    typed_equal(page["headers"]["complete"], True, "complete body")
    raw = page["raw_body"].encode()
    v.require(len(raw) <= 1024 ** 2, "OS17 response oversized")
    typed_equal(page["headers"]["body_bytes"], len(raw), "body byte count")
    body = json.loads(raw)
    v.search_complete(body, 8)
    typed_equal(body["timed_out"], False, "timeout")
    typed_equal(body["hits"]["total"], {"value": 8, "relation": "eq"}, "total")
    typed_equal(body["_shards"], {"total": 1, "successful": 1, "skipped": 0, "failed": 0}, "shards")
    v.require("error" not in body, "search error envelope")
    return body


def hit_binding(hit, doc, index):
    typed_equal(hit["_index"], index, "concrete index")
    typed_equal(hit["_id"], doc["event_id"], "event ID")
    typed_equal(hit["_source"], doc, "literal source")
    typed_equal(hit["sort"], [doc["sequence"], doc["event_id"]], "sort")


def request_binding(page, position, previous):
    expected = json.loads(json.dumps(REQUEST))
    if position:
        expected["search_after"] = CURSORS[position]
        typed_equal(page["request"]["search_after"], previous, "actual cursor propagation")
    typed_equal(page["request"], expected, "literal request")
    typed_equal(json.loads(page["raw_request"]), expected, "raw request binding")
    v.require(len(page["raw_request"].encode()) <= 1024 ** 2, "request oversized")


def boundary(docs):
    typed_equal([doc["attempt"] for doc in docs], [1, 1, 1, 1, 1, 2, 2, 2], "attempts")
    typed_equal([doc["sequence"] for doc in docs], [1, 2, 3, 4, 5, 6, 7, 8], "producer order")
    for position in (3, 4, 6):
        typed_equal(docs[position]["action_id"], "alpha:job-action-retry:followup:v1", "stable intended action")
    typed_equal(docs[4]["event_type"], "ACTION_CONFIRMED", "confirmation before restart")
    typed_equal(docs[5]["event_type"], "STARTED", "later restart record")
    typed_equal([doc["event_id"] for doc in docs if doc["event_type"] == "COMPLETED"], ["alpha:job-action-retry:a2:s08"], "only recorded completion")


def verify(bundle, oracle, binding):
    typed_equal(bundle["source_binding"], binding, "tested source binding")
    v.require(bundle["index"].endswith("-os17-action-retry"), "wrong index role")
    v.require(bundle["index"] != bundle["main_index"], "separate index required")
    typed_equal(len(bundle["pages"]), 4, "exact four requests")
    position, previous, documents = 0, None, []
    for number, page in enumerate(bundle["pages"]):
        request_binding(page, number, previous)
        body = page_complete(page)
        hits = body["hits"]["hits"]
        typed_equal(len(hits), LENGTHS[number], "page length")
        for hit in hits:
            hit_binding(hit, oracle[position], bundle["index"])
            documents.append(hit["_source"])
            position += 1
        if hits:
            previous = hits[-1]["sort"]
    typed_equal(position, 8, "eight literal records")
    boundary(documents)
    return {"label": LABEL, "page_lengths": LENGTHS, "documents": documents, "action_id": "alpha:job-action-retry:followup:v1", "external_receipt": None}
