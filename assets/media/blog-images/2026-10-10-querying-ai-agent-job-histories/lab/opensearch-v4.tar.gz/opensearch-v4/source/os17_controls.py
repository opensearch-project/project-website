"""Exact checker mutations, applied to copies of a supplied OS17 bundle."""

import copy
import json
import subprocess
import sys
from pathlib import Path
from transport import now, write_json
import verifier as v


def body(bundle, page=1):
    return json.loads(bundle["pages"][page]["raw_body"])


def replace_body(bundle, value, page=1):
    raw = json.dumps(value)
    bundle["pages"][page]["raw_body"] = raw
    bundle["pages"][page]["headers"]["body_bytes"] = len(raw.encode())


def wrong_action(bundle):
    value = body(bundle, 2)
    value["hits"]["hits"][0]["_source"]["action_id"] = "alpha:job-retry:followup:v1"
    replace_body(bundle, value, 2)


def uniform_wrong_action(bundle):
    for page in (1, 2):
        value = body(bundle, page)
        for hit in value["hits"]["hits"]:
            if "action_id" in hit["_source"]:
                hit["_source"]["action_id"] = "alpha:job-retry:followup:v1"
        replace_body(bundle, value, page)


def missing_confirmation(bundle):
    hits = [hit for page in bundle["pages"] for hit in json.loads(page["raw_body"])["hits"]["hits"] if hit["_source"]["sequence"] != 5]
    previous = None
    for number, page in enumerate(bundle["pages"]):
        value = body(bundle, number)
        value["hits"]["total"]["value"] = 7
        value["hits"]["hits"] = hits[number * 3:number * 3 + 3]
        if number:
            page["request"]["search_after"] = previous
            page["raw_request"] = json.dumps(page["request"])
        if value["hits"]["hits"]:
            previous = value["hits"]["hits"][-1]["sort"]
        replace_body(bundle, value, number)


def reordered_boundary(bundle):
    value = body(bundle)
    hits = value["hits"]["hits"]
    hits[1], hits[2] = hits[2], hits[1]
    replace_body(bundle, value)


def altered_sequence(bundle):
    value = body(bundle)
    hits = value["hits"]["hits"]
    hits[1]["_source"]["sequence"], hits[2]["_source"]["sequence"] = 6, 5
    hits[1]["sort"][0], hits[2]["sort"][0] = 6, 5
    hits[1], hits[2] = hits[2], hits[1]
    replace_body(bundle, value)


def cut_json(bundle):
    page = bundle["pages"][1]
    page["raw_body"] = page["raw_body"][:len(page["raw_body"]) // 2]
    page["headers"]["body_bytes"] = len(page["raw_body"].encode())


def omit_hit(bundle):
    value = body(bundle)
    value["hits"]["hits"].pop(1)
    replace_body(bundle, value)


def omit_terminal(bundle):
    bundle["pages"].pop()


def failed_shard(bundle):
    value = body(bundle)
    value["_shards"] = {"total": 1, "successful": 0, "skipped": 0, "failed": 1}
    replace_body(bundle, value)


def inexact_total(bundle):
    value = body(bundle)
    value["hits"]["total"]["relation"] = "gte"
    replace_body(bundle, value)


def wrong_total(bundle):
    value = body(bundle)
    value["hits"]["total"]["value"] = 9
    replace_body(bundle, value)


def timed_out(bundle):
    value = body(bundle)
    value["timed_out"] = True
    replace_body(bundle, value)


def source_changed(bundle):
    bundle["source_binding"]["source/application.py"] = "0" * 64


MUTATIONS = [wrong_action, uniform_wrong_action, missing_confirmation, reordered_boundary, altered_sequence, cut_json, omit_hit, omit_terminal, failed_shard, inexact_total, wrong_total, timed_out, source_changed]


def run(bundle, oracle, binding, output, origin):
    output = Path(output)
    v.require(not output.exists(), "fresh control evidence required")
    output.mkdir(parents=True)
    write_json(output / "binding.json", binding)
    write_json(output / "oracle.json", oracle)
    records = []
    for mutation in MUTATIONS:
        altered = copy.deepcopy(bundle)
        mutation(altered)
        target = output / (mutation.__name__ + ".bundle.json")
        write_json(target, altered)
        records.append(check(target, output, mutation.__name__, origin))
    write_json(output / "results.json", {"origin": origin, "controls": records, "product_requests": 0, "status": "CHECKER_SENSITIVITY_ONLY"})
    return records


def check(target, output, name, origin):
    argv = [sys.executable, str(Path(__file__).with_name("os17_check.py")), "--bundle", str(target), "--oracle", str(output / "oracle.json"), "--binding", str(output / "binding.json")]
    started = now()
    result = subprocess.run(argv, capture_output=True, timeout=15, check=False)
    (output / (name + ".stdout")).write_bytes(result.stdout)
    (output / (name + ".stderr")).write_bytes(result.stderr)
    record = {"argv": argv, "start_gst": started, "end_gst": now(), "exit": result.returncode, "origin": origin, "mutation": name, "stdout": name + ".stdout", "stderr": name + ".stderr", "product_requests": 0}
    with (output / "commands.jsonl").open("a") as file:
        file.write(json.dumps(record) + "\n")
    v.equal(result.returncode, 1, "negative checker exit")
    return record
