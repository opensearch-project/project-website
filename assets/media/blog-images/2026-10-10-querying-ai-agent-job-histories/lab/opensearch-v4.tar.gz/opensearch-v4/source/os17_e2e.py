"""Separate OS17 E2E case, authored before fixture registration."""

import json
from pathlib import Path
import application
import os17_controls
import os17_verifier as ov
import verifier as v
from transport import write_json


def captured_page(suite, request, prefix):
    return read_capture(suite.client, request, prefix)


def read_capture(client, request, prefix):
    raw = (client.evidence / "responses" / (prefix + ".json")).read_text()
    headers = v.load(client.evidence / "responses" / (prefix + ".headers.json"))
    raw_request = (client.evidence / "requests" / (prefix + ".body")).read_text()
    return {"request": request, "raw_request": raw_request, "status": headers["status"], "headers": headers, "raw_body": raw, "capture_prefix": prefix}


def configuration(suite, index):
    mappings = suite.request("os17-mapping-" + index, "GET", f"/{index}/_mapping")
    actual_mapping = mappings[index]["mappings"]
    ov.typed_equal(actual_mapping["properties"], suite.mapping["mappings"]["properties"], "declared property mappings")
    ov.typed_equal(actual_mapping["dynamic"], "strict", "declared dynamic mapping")
    v.require("_source" not in actual_mapping or actual_mapping["_source"] == {"enabled": True}, "retained source, explicit or source-defined default")
    settings = suite.request("os17-settings-" + index, "GET", f"/{index}/_settings")
    actual = settings[index]["settings"]["index"]
    for key, value in suite.mapping["settings"]["index"].items():
        v.equal(actual[key], str(value), "declared index setting")
    return {"mappings": mappings, "settings": settings, "declared": suite.mapping}


def timeline(suite):
    start = suite.client.request_count
    client = TimelineClient(suite.client)
    responses, requests = application.search_after(client, suite.os17_index, application.history_request("alpha", "job-action-retry", 3), "os17-timeline")
    v.equal(len(responses), 4, "four captured pages")
    return [captured_page(suite, request, f"{start + position + 1:04d}-os17-timeline-page-{position}") for position, request in enumerate(requests)]


class TimelineClient:
    def __init__(self, client):
        self.client = client
        self.count = 0

    def request(self, name, method, path, request):
        v.require(self.count < 4, "OS17 fifth request forbidden")
        self.count += 1
        body = self.client.request(name, method, path, request)
        prefix = f"{self.client.request_count:04d}-{name}"
        ov.page_complete(read_capture(self.client, request, prefix))
        validate_cursor(body["hits"]["hits"])
        return body


def validate_cursor(hits):
    if not hits:
        return
    cursor = hits[-1]["sort"]
    v.require(type(cursor) is list and len(cursor) == 2, "cursor shape")
    v.require(type(cursor[0]) is int and type(cursor[1]) is str, "cursor types")


def execute(suite, root, binding):
    oracle = v.load(Path(__file__).with_name("os17-expectations.json"))
    fixture = v.load(Path(__file__).with_name("os17-fixtures.json"))
    suite.os17_index = f"{suite.run_id}-os17-action-retry"
    identity = {"index": suite.os17_index, "main_index": suite.main, "role": "os17-action-retry", "created": False}
    write_json(root / "index-identity.json", identity)
    write_json(root / "expected.json", oracle)
    write_json(root / "binding.json", binding)
    index = suite.create_index("os17-action-retry")
    identity["created"] = True
    write_json(root / "index-identity.json", identity)
    try:
        setup(suite, root, fixture)
        bundle = {"index": index, "main_index": suite.main, "source_binding": binding, "origin": "CAPTURED_PRODUCT_RESPONSES", "pages": timeline(suite)}
        write_json(root / "bundle.json", bundle)
        result = ov.verify(bundle, oracle, binding)
        write_json(root / "comparison.json", {"status": "PASS", "observed": result, "bundle": "bundle.json", "binding": "binding.json"})
        os17_controls.run(bundle, oracle, binding, root / "negative-controls", "COPIES_OF_CAPTURED_PRODUCT_RESPONSES")
        unchanged_main(suite, root)
    except Exception as error:
        write_json(root / "case-failure.json", {"error": f"{type(error).__name__}: {error}"})
        raise
    finally:
        cleanup(suite, root, identity)


def setup(suite, root, fixture):
    configurations = {index: configuration(suite, index) for index in (suite.main, suite.os17_index)}
    ov.typed_equal(configurations[suite.main]["mappings"][suite.main], configurations[suite.os17_index]["mappings"][suite.os17_index], "identical effective mappings")
    write_json(root / "configuration.json", configurations)
    ids = ["alpha:job-action-retry:a2:s08", "alpha:job-action-retry:a2:s07", "alpha:job-action-retry:a2:s06", "alpha:job-action-retry:a1:s05", "alpha:job-action-retry:a1:s04", "alpha:job-action-retry:a1:s03", "alpha:job-action-retry:a1:s02", "alpha:job-action-retry:a1:s01"]
    lookup = {doc["event_id"]: doc for doc in fixture}
    sanitized = suite.ingest(suite.os17_index, [lookup[event_id] for event_id in ids], "os17-create-eight")
    bulk = v.load(suite.evidence / "responses" / f"{suite.client.request_count:04d}-os17-create-eight.json")
    ov.typed_equal(bulk["errors"], False, "bulk errors")
    for item in bulk["items"]:
        ov.typed_equal(item["create"]["status"], 201, "typed create status")
    write_json(root / "bulk-response.json", bulk)
    write_json(root / "submitted.json", sanitized)
    (root / "submitted.ndjson").write_bytes(application.ndjson(sanitized))
    refresh = suite.request("os17-explicit-refresh", "POST", f"/{suite.os17_index}/_refresh")
    ov.typed_equal(refresh["_shards"]["failed"], 0, "refresh failed shards")
    write_json(root / "ingestion-paused.json", {"status": "PAUSED", "additional_fixture_writes": 0, "until": "all four timeline responses captured"})


def unchanged_main(suite, root):
    records = {}
    for tenant, total in (("alpha", 27), ("beta", 6)):
        response = suite.search(suite.main, application.tenant_request(tenant), "os17-main-unchanged-" + tenant)
        v.search_complete(response, total)
        expected = suite.queries["Q06"]["responses"][1 if tenant == "alpha" else 3]
        ov.typed_equal(v.sources(response), v.sources(expected), "original main corpus unchanged")
        records[tenant] = response
    write_json(root / "main-unchanged.json", records)


def cleanup(suite, root, identity):
    v.equal(identity["index"], suite.run_id + "-os17-action-retry", "exact owned index")
    deleted = suite.request("os17-delete-owned-index", "DELETE", "/" + identity["index"])
    v.equal(deleted["acknowledged"], True, "index deletion acknowledgment")
    absent = suite.request("os17-verify-index-absence", "GET", "/" + identity["index"], statuses=(404,))
    v.equal(absent["error"]["type"], "index_not_found_exception", "deleted index absent")
    write_json(root / "cleanup.json", {"status": "PASS", "deleted_index": identity["index"], "absent": True, "main_index_preserved": suite.main})


def run(suite):
    root = suite.evidence / "OS17"
    root.mkdir()
    binding = v.load(suite.evidence / "ownership.json")["source_hashes"]
    try:
        execute(suite, root, binding)
    except Exception as error:
        record = {"id": "OS17", "status": "FAIL", "error": f"{type(error).__name__}: {error}"}
        append_result(suite, record)
        raise
    append_result(suite, {"id": "OS17", "status": "PASS", "evidence": "OS17/", "label": ov.LABEL})


def append_result(suite, record):
    results = v.load(suite.evidence / "results.json")
    results["cases"].append(record)
    results["status"] = record["status"]
    write_json(suite.evidence / "results.json", results)
    write_json(suite.evidence / "OS17" / "result.json", record)


def blocked(evidence):
    root = evidence / "OS17"
    if (root / "result.json").exists():
        return
    record = {"id": "OS17", "status": "BLOCKED", "gate": "earlier mandatory readiness/original suite failure", "observed": None}
    write_json(root / "result.json", record)
    if (evidence / "results.json").exists():
        results = v.load(evidence / "results.json")
        results["cases"].append(record)
        write_json(evidence / "results.json", results)
