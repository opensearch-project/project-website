"""Frozen E2E suite. Run only in an owned driver on the isolated real product."""

import copy
import json
import subprocess
import sys
from pathlib import Path
from transport import now

import application
import verifier as v


MARKERS = ["FAKE_PROMPT_817", "FAKE_HEADER_284", "FAKE_DEBUG_395", "FAKE_OUTPUT_496", "FAKE_EXTRA_507"]
CASES = ["OS01", "OS02", "OS03", "OS04", "OS05a", "OS05b", "OS06", "OS07", "OS08", "OS09", "OS10", "OS11", "OS12", "OS13", "OS14"]


class Suite:
    def __init__(self, client, run_id, evidence, identity):
        self.client = client
        self.run_id = run_id
        self.evidence = Path(evidence)
        self.identity = identity
        self.oracle = v.load(Path(__file__).with_name("fixture-expectations.json"))
        self.raw = v.load(Path(__file__).with_name("fixtures.json"))
        application.sanitize_batch(self.raw)
        self.mapping = v.load(Path(__file__).with_name("mapping.json"))
        self.main = f"{run_id}-main"
        self.assertions = []
        self.queries = {}

    def request(self, name, method, path, body=None, statuses=(200,)):
        return self.client.request(name, method, path, body, statuses)

    def create_index(self, suffix, refresh="1s"):
        index = f"{self.run_id}-{suffix}"
        spec = copy.deepcopy(self.mapping)
        spec["settings"]["index"]["refresh_interval"] = refresh
        body = self.request(f"index-{suffix}", "PUT", f"/{index}", spec)
        v.equal(body["acknowledged"], True, "index acknowledgment")
        return index

    def create(self, index, doc, name, refresh="false", statuses=(201,)):
        path = f"/{index}/_create/{doc['event_id']}?refresh={refresh}"
        return self.request(name, "PUT", path, doc, statuses)

    def get(self, index, event_id, name, statuses=(200,)):
        return self.request(name, "GET", f"/{index}/_doc/{event_id}", statuses=statuses)

    def search(self, index, request, name):
        return self.request(name, "POST", f"/{index}/_search", request)

    def history_request(self, tenant, job, size=100):
        return application.history_request(tenant, job, size)

    def query(self, query_id, request, total, index=None):
        body = self.search(index or self.main, request, query_id)
        v.search_complete(body, total)
        self.queries[query_id] = {"requests": [request], "responses": [body]}
        return body

    def ingest(self, index, docs, name):
        sanitized = application.sanitize_batch(docs)
        data = application.ndjson(sanitized)
        response = self.request(name, "POST", f"/{index}/_bulk?refresh=wait_for", data)
        event_ids = [doc["event_id"] for doc in sanitized]
        v.bulk(response, event_ids, [201] * len(docs), [None] * len(docs))
        return sanitized

    def OS01(self):
        root = self.request("identity", "GET", "/")
        v.equal(root["version"]["number"], "3.9.0", "version")
        v.equal(root["cluster_name"], self.run_id, "cluster identity")
        v.require(bool(root["version"]["build_hash"]), "missing build hash")
        application.check_runtime_identity(self.identity, self.run_id)
        guard = self.create_index("probe")
        mappings = self.request("mapping-readback", "GET", f"/{guard}/_mapping")
        v.equal(mappings[guard]["mappings"]["properties"], self.mapping["mappings"]["properties"], "explicit field mappings")
        v.equal(mappings[guard]["mappings"]["dynamic"], "strict", "strict mapping")
        settings = self.request("index-settings", "GET", f"/{guard}/_settings?include_defaults=true")
        effective = settings[guard]["settings"]["index"]
        v.equal(effective["number_of_shards"], "1", "primary shards")
        v.equal(effective["number_of_replicas"], "0", "replicas")
        settings = self.request("cluster-settings", "GET", "/_cluster/settings?include_defaults=true&flat_settings=true")
        v.disk_guards(settings)
        filesystem = self.request("node-filesystem", "GET", "/_nodes/stats/fs")
        v.node_filesystem(filesystem, self.identity)
        self.request("node-effective-settings", "GET", "/_nodes/settings?flat_settings=true&timeout=15s")
        jvm = self.request("node-jvm", "GET", "/_nodes/jvm?timeout=15s")
        v.jvm_heap(jvm)
        health = self.request("health", "GET", "/_cluster/health?wait_for_status=green&timeout=15s")
        v.equal(health["timed_out"], False, "health timeout")
        v.equal(health["status"], "green", "health")
        doc = application.sanitize(self.raw[0])
        self.create(guard, doc, "probe-create", "wait_for")
        stored = self.get(guard, doc["event_id"], "probe-get")
        v.equal(stored["_source"], doc, "probe readback")
        self.client.start_suite_deadline()
        self.create_index("main")
        self.request("main-block-state-before", "GET", f"/{self.main}/_settings?include_defaults=true&flat_settings=true")
        initial = [doc for doc in self.raw if doc["event_id"] != "alpha:job-late:a1:s07"]
        self.ingest(self.main, initial, "main-initial-32")
        before = self.query("Q05-before", self.history_request("alpha", "job-late"), 6)
        v.history(before, self.oracle["Q05"]["before_ids"])

    def OS02(self):
        index = self.create_index("redaction")
        raw = copy.deepcopy(self.raw[0])
        raw.update({"prompt": MARKERS[0], "headers": {"Authorization": MARKERS[1]}, "debug": {"nested": MARKERS[2]}, "output": MARKERS[3], "extra": MARKERS[4]})
        sanitized = self.ingest(index, [raw], "redaction-submitted")
        v.redacted(sanitized[0], MARKERS, application.FIELDS)
        stored = self.get(index, raw["event_id"], "redaction-get")
        v.redacted(stored["_source"], MARKERS, application.FIELDS)
        bad = copy.deepcopy(raw)
        bad["job_id"] = "FAKE_SECRET_INVALID/ID"
        count = self.client.request_count
        v.rejects(application.sanitize, bad)
        v.equal(self.client.request_count, count, "invalid allowed value submitted")
        full = self.search(index, {"size": 100, "track_total_hits": True, "query": {"match_all": {}}}, "redaction-full")
        v.search_complete(full, 1)
        for source in v.sources(full):
            v.redacted(source, MARKERS, application.FIELDS)

    def OS03(self):
        index = self.create_index("duplicate")
        doc = application.sanitize(self.raw[0])
        self.duplicate_index = index
        first = self.create(index, doc, "duplicate-first", "wait_for")
        conflict = self.create(index, doc, "duplicate-second", statuses=(409,))
        v.equal(conflict["error"]["type"], "version_conflict_engine_exception", "duplicate error")
        stored = self.get(index, doc["event_id"], "duplicate-readback")
        v.equal(application.classify_conflict(doc, stored["_source"]), "DUPLICATE", "duplicate comparison")
        v.equal(stored["_source"], doc, "duplicate original")
        v.equal(stored["_version"], first["_version"], "duplicate version")
        rerun = application.sanitize_batch([self.raw[0]])[0]
        v.equal(rerun, doc, "loader rerun identity")
        self.create(index, rerun, "duplicate-loader-rerun", statuses=(409,))
        v.history(self.search(index, self.history_request(doc["tenant_id"], doc["job_id"]), "duplicate-count"), [doc["event_id"]])

    def OS04(self):
        doc = application.sanitize(self.raw[0])
        before = self.get(self.duplicate_index, doc["event_id"], "conflict-before")
        changed = copy.deepcopy(doc)
        changed["ingested_at"] = "2026-10-01T12:05:00.000+04:00"
        response = self.create(self.duplicate_index, changed, "conflict-write", statuses=(409,))
        v.equal(response["error"]["type"], "version_conflict_engine_exception", "conflict error")
        after = self.get(self.duplicate_index, doc["event_id"], "conflict-after")
        v.equal(application.classify_conflict(changed, after["_source"]), "CONFLICTING_EVENT", "canonical mismatch")
        v.equal(after["_source"], before["_source"], "conflict source unchanged")
        v.equal(after["_version"], before["_version"], "conflict version unchanged")

    def OS05a(self):
        index = self.create_index("visibility-disabled", "-1")
        doc = application.sanitize(self.raw[0])
        self.create(index, doc, "visibility-create", "false")
        v.equal(self.get(index, doc["event_id"], "visibility-realtime")["_source"], doc, "realtime GET")
        request = self.history_request(doc["tenant_id"], doc["job_id"])
        v.history(self.search(index, request, "visibility-before"), [])
        refresh = self.request("visibility-refresh", "POST", f"/{index}/_refresh")
        v.equal(refresh["_shards"]["failed"], 0, "refresh failed")
        v.history(self.search(index, request, "visibility-after"), [doc["event_id"]])

    def OS05b(self):
        index = self.create_index("visibility-normal", "1s")
        doc = application.sanitize(self.raw[0])
        self.create(index, doc, "wait-for-create", "wait_for")
        v.history(self.search(index, self.history_request(doc["tenant_id"], doc["job_id"]), "wait-for-search"), [doc["event_id"]])

    def complete_main(self):
        late = [doc for doc in self.raw if doc["event_id"] == "alpha:job-late:a1:s07"]
        self.ingest(self.main, late, "main-late-claim")

    def OS06(self):
        self.complete_main()
        request = v.load(Path(__file__).with_name("queries") / "Q01.json")
        pages, requests = application.search_after(self.client, self.main, request, "Q01")
        v.query01(pages, self.oracle["Q01"])
        self.queries["Q01"] = {"requests": requests, "responses": pages}
        altered = copy.deepcopy(pages)
        altered[1]["hits"]["hits"].pop()
        self.save("negative-controls/truncated-Q01.json", altered)
        v.rejects(v.query01, altered, self.oracle["Q01"])
        self.nonzero("Q01", altered, self.oracle["Q01"], "truncated-Q01")

    def OS07(self):
        request = v.load(Path(__file__).with_name("queries") / "Q02.json")
        pages, requests = application.composite(self.client, self.main, request, "Q02")
        retry_jobs = application.retry_jobs(pages)
        v.query02(pages, self.oracle["Q02"], retry_jobs)
        self.queries["Q02"] = {"requests": requests, "responses": pages, "presentation": retry_jobs}
        body = self.query("Q03", v.load(Path(__file__).with_name("queries") / "Q03.json"), 2)
        v.history(body, self.oracle["Q03"]["ids"])

    def OS08(self):
        expected = self.oracle["histories"]["alpha/job-ok"]
        request = self.history_request("alpha", "job-ok")
        first = self.search(self.main, request, "ties-main")
        v.history(first, expected)
        tied = v.sources(first)[3:5]
        v.equal(tied[0]["event_time"], tied[1]["event_time"], "event time tie")
        v.equal(tied[0]["ingested_at"], tied[1]["ingested_at"], "ingestion time tie")
        index = self.create_index("reverse-ties")
        docs = [doc for doc in self.raw if doc["tenant_id"] == "alpha" and doc["job_id"] == "job-ok"]
        docs.sort(key=application.producer_sequence, reverse=True)
        self.ingest(index, docs, "reverse-ties-submitted")
        v.history(self.search(index, request, "ties-reversed"), expected)

    def OS09(self):
        before = self.queries["Q05-before"]["responses"][0]
        after = self.query("Q05", v.load(Path(__file__).with_name("queries") / "Q05.json"), 7)
        interpretation = application.interpret_history(v.sources(after))
        v.query05(before, after, self.oracle["Q05"], interpretation)
        self.queries["Q05"]["before"] = self.queries["Q05-before"]
        self.queries["Q05"]["presentation"] = interpretation
        v.rejects(v.query05, before, after, self.oracle["Q05"], {"state": "JOB_FAILED", "supporting_ids": []})

    def OS10(self):
        body = self.query("Q04", v.load(Path(__file__).with_name("queries") / "Q04.json"), 1)
        interpretation = application.unknown_interpretation()
        v.query04(body, self.oracle["Q04"], interpretation)
        self.queries["Q04"]["presentation"] = interpretation

    def OS11(self):
        requests = []
        responses = []
        definitions = v.load(Path(__file__).with_name("queries") / "Q06.json")["variants"]
        for position, tenant in enumerate(("alpha", "beta")):
            request = definitions[position]
            v.tenant_request(request, tenant)
            body = self.search(self.main, request, f"Q06-{tenant}-job")
            v.history(body, self.oracle["histories"][f"{tenant}/job-ok"])
            inventory = definitions[position + 2]
            v.tenant_request(inventory, tenant)
            full = self.search(self.main, inventory, f"Q06-{tenant}-full")
            expected = sorted(self.tenant_ids(tenant))
            v.history(full, expected)
            v.fixture_sources(v.sources(full), self.oracle)
            for source in v.sources(full):
                v.redacted(source, MARKERS, application.FIELDS)
                v.schema(source)
            requests.extend([request, inventory])
            responses.extend([body, full])
        v.equal(len(set(v.ids(responses[1])) & set(v.ids(responses[3]))), 0, "tenant collision")
        self.queries["Q06"] = {"requests": requests, "responses": responses}
        for query_id in ("Q01", "Q03", "Q04", "Q05"):
            v.tenant_request(v.load(Path(__file__).with_name("queries") / f"{query_id}.json"), "alpha")

    def tenant_ids(self, tenant):
        return [event_id for job, event_ids in self.oracle["histories"].items() if job.startswith(tenant + "/") for event_id in event_ids]

    def OS12(self):
        index = self.create_index("mixed-bulk")
        base = sorted([application.sanitize(doc) for doc in self.raw if doc["tenant_id"] == "alpha" and doc["job_id"] == "job-ok"], key=application.producer_sequence)
        docs = [base[0], base[0], copy.deepcopy(base[1]), copy.deepcopy(base[2]), base[3]]
        docs[2]["sequence"] = "invalid-sequence"
        docs[3]["unmapped_field"] = "invalid-field"
        response = self.request("mixed-bulk-submitted", "POST", f"/{index}/_bulk?refresh=wait_for", application.ndjson(docs))
        expected = self.oracle["OS12"]
        v.bulk(response, expected["ids"], expected["statuses"], expected["error_types"])
        for doc in (base[0], base[3]):
            v.equal(self.get(index, doc["event_id"], "mixed-valid-" + str(doc["sequence"]))["_source"], doc, "mixed valid source")
        for doc in (base[1], base[2]):
            v.equal(self.get(index, doc["event_id"], "mixed-invalid-" + str(doc["sequence"]), (404,))["found"], False, "invalid row exists")
        original = self.get(index, base[0]["event_id"], "mixed-duplicate-original")
        v.equal(original["_version"], 1, "mixed duplicate changed version")
        v.equal(original["_source"], base[0], "mixed duplicate original")
        self.mixed_response = response

    def OS13(self):
        request = application.tenant_request("alpha")
        before = self.search(self.main, request, "invalid-before")
        bad_inputs = application_invalid_inputs(self.raw[0])
        for bad in bad_inputs:
            count = self.client.request_count
            v.rejects(application.sanitize_batch, bad)
            v.equal(self.client.request_count, count, "invalid input sent HTTP")
        after = self.search(self.main, request, "invalid-after")
        v.equal(v.sources(after), v.sources(before), "corpus changed")
        v.search_complete(after, 27)

    def OS14(self):
        doc = application.sanitize(self.raw[0])
        altered = copy.deepcopy(doc)
        altered["prompt"] = MARKERS[0]
        v.rejects(v.redacted, altered, MARKERS, application.FIELDS)
        self.nonzero("redaction", altered, {"markers": MARKERS, "allowed": application.FIELDS}, "retained-marker")
        altered = copy.deepcopy(doc)
        altered["unknown"] = "unlisted"
        v.rejects(v.redacted, altered, MARKERS, application.FIELDS)
        self.nonzero("redaction", altered, {"markers": MARKERS, "allowed": application.FIELDS}, "unlisted-field")
        altered = copy.deepcopy(doc)
        altered["sequence"] = "1"
        self.nonzero("schema", altered, {}, "wrong-schema-type")
        for mutation in (omit_bulk_item, clear_bulk_error):
            bad = copy.deepcopy(self.mixed_response)
            mutation(bad)
            expected = self.oracle["OS12"]
            v.rejects(v.bulk, bad, expected["ids"], expected["statuses"], expected["error_types"])
            self.nonzero("bulk", bad, expected, mutation.__name__)
        for mutation in (shard_failure, timed_out):
            bad = copy.deepcopy(self.queries["Q03"]["responses"][0])
            mutation(bad)
            v.rejects(v.history, bad, self.oracle["Q03"]["ids"])
            self.nonzero("history", bad, self.oracle["Q03"]["ids"], mutation.__name__)

    def nonzero(self, mode, actual, expected, name):
        root = self.evidence / "negative-controls"
        self.save(f"negative-controls/{name}.actual.json", actual)
        self.save(f"negative-controls/{name}.expected.json", expected)
        argv = [sys.executable, str(Path(__file__).with_name("verify_cli.py")), "--mode", mode, "--actual", str(root / f"{name}.actual.json"), "--expected", str(root / f"{name}.expected.json")]
        started = now()
        result = subprocess.run(argv, capture_output=True, timeout=15, check=False)
        (root / f"{name}.stdout").write_bytes(result.stdout)
        (root / f"{name}.stderr").write_bytes(result.stderr)
        self.client.append_command({"argv": argv, "cwd": str(Path.cwd()), "start_gst": started, "end_gst": now(), "timeout_seconds": 15, "exit": result.returncode, "expected_exit": 1, "stdout_artifact": f"negative-controls/{name}.stdout", "stderr_artifact": f"negative-controls/{name}.stderr"})
        v.equal(result.returncode, 1, "checker negative control must exit nonzero")

    def save(self, relative, value):
        path = self.evidence / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")

    def save_queries(self):
        for query_id in ("Q01", "Q02", "Q03", "Q04", "Q05", "Q06"):
            record = self.queries[query_id]
            root = f"queries/{query_id}"
            self.save(f"{root}/expected.json", self.oracle[query_id])
            self.save(f"{root}/comparison.json", {"status": "PASS", "oracle": "fixture-expectations.json", "observed": record.get("presentation")})
            self.save(f"{root}/requests.json", record["requests"])
            self.save(f"{root}/responses.json", record["responses"])
            self.save(f"{root}/record.json", record)
            for page_number, (request, response) in enumerate(zip(record["requests"], record["responses"])):
                self.save(f"{root}/request-{page_number}.json", request)
                self.save(f"{root}/response-{page_number}.json", response)
            self.save(f"{root}/repeat.json", {"command": "python3 -I -S -B \"$LAB_ROOT/source/trusted_bootstrap.py\" --package \"$LAB_ROOT\" --manifest \"$LAB_ROOT/execution-manifest.json\" --manifest-sha256 \"$EXECUTION_MANIFEST_SHA256\" --entry runtime -- launch --root NEW_OWNED_ROOT --run-id NEW_RUN_ID --shared-baseline SHARED_BUDGET_JSON --execute-authorized", "query": query_id, "require_fresh_run": True, "endpoint": "owned network only", "identity": self.run_id})

    def run(self):
        for case in CASES:
            self.run_case(case)
        self.save_queries()
        self.request("main-block-state-after", "GET", f"/{self.main}/_settings?include_defaults=true&flat_settings=true")
        self.save("results.json", {"status": "PASS", "cases": self.assertions, "live_product": True})

    def run_case(self, case):
        try:
            getattr(self, case)()
        except Exception as error:
            self.assertions.append({"id": case, "status": "FAIL", "error": f"{type(error).__name__}: {error}"})
            done = {record["id"] for record in self.assertions}
            self.assertions.extend({"id": pending, "status": "BLOCKED", "gate": "earlier mandatory case failed"} for pending in CASES if pending not in done)
            self.save("assertions.json", self.assertions)
            self.save("results.json", {"status": "FAIL", "cases": self.assertions, "live_product": True})
            raise
        self.assertions.append({"id": case, "status": "PASS", "oracle": "fixture-expectations.json", "evidence": "requests/ and responses/"})
        self.save("assertions.json", self.assertions)


def application_invalid_inputs(raw):
    missing = copy.deepcopy(raw)
    missing.pop("event_time")
    negative = copy.deepcopy(raw)
    negative["attempt"] = -1
    wrong_type = copy.deepcopy(raw)
    wrong_type["attempt"] = "1"
    malformed = copy.deepcopy(raw)
    malformed["event_time"] = "not-a-time"
    reused = copy.deepcopy(raw)
    reused["event_id"] = "alpha:job-ok:a2:s01"
    reused["attempt"] = 2
    return [[missing], [negative], [wrong_type], [malformed], [raw, reused]]


def omit_bulk_item(body):
    body["items"].pop()


def clear_bulk_error(body):
    body["errors"] = False


def shard_failure(body):
    body["_shards"]["failed"] = 1


def timed_out(body):
    body["timed_out"] = True
