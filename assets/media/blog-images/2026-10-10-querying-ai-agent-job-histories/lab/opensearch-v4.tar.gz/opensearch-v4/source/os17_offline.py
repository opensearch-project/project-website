"""Offline checker sensitivity only; never makes OpenSearch requests."""

import argparse
import hashlib
import json
from pathlib import Path
import application
import os17_controls
import os17_verifier as ov
import verifier as v
from transport import write_json


def authored_bundle(oracle, binding):
    pages = []
    for position, length in enumerate([3, 3, 2, 0]):
        docs = oracle[position * 3:position * 3 + length]
        hits = [{"_index": "offline-authored-os17-action-retry", "_id": doc["event_id"], "_source": doc, "sort": [doc["sequence"], doc["event_id"]]} for doc in docs]
        request = json.loads(json.dumps(ov.REQUEST))
        if position:
            request["search_after"] = ov.CURSORS[position]
        raw = json.dumps({"timed_out": False, "_shards": {"total": 1, "successful": 1, "skipped": 0, "failed": 0}, "hits": {"total": {"value": 8, "relation": "eq"}, "hits": hits}})
        pages.append({"request": request, "raw_request": json.dumps(request), "status": 200, "headers": {"complete": True, "body_bytes": len(raw.encode())}, "raw_body": raw})
    return {"index": "offline-authored-os17-action-retry", "main_index": "offline-main", "source_binding": binding, "origin": "OFFLINE_AUTHORED_SYNTHETIC_INPUT_NOT_PRODUCT_OUTPUT", "pages": pages}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--oracle", required=True)
    parser.add_argument("--evidence", required=True)
    parser.add_argument("--baseline", action="store_true")
    args = parser.parse_args()
    oracle = v.load(args.oracle)
    output = Path(args.evidence)
    v.require(not output.exists(), "fresh offline evidence required")
    output.mkdir(parents=True)
    if args.baseline:
        application.sanitize_batch(oracle)
        raise AssertionError("pre-amendment loader unexpectedly accepts OS17")
    fixture = v.load(Path(__file__).with_name("os17-fixtures.json"))
    ov.typed_equal(application.sanitize_batch(fixture), oracle, "independent literal fixture")
    v.equal(application.history_request("alpha", "job-action-retry", 3), ov.REQUEST, "query contract")
    binding = {"source/" + path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in Path(__file__).parent.glob("*.py")}
    bundle = authored_bundle(oracle, binding)
    write_json(output / "authored-bundle.json", bundle)
    ov.verify(bundle, oracle, binding)
    records = os17_controls.run(bundle, oracle, binding, output / "negative-controls", bundle["origin"])
    write_json(output / "results.json", {"status": "OFFLINE_CHECKER_LOGIC_VERIFIED", "product_requests": 0, "live_status": "NOT_RUN", "controls": len(records), "positive_origin": bundle["origin"]})


if __name__ == "__main__":
    main()
