"""Single-attempt HTTP capture with absolute deadlines and size bounds."""

import hashlib
import http.client
import json
import signal
import time
from datetime import datetime, timezone, timedelta
from pathlib import Path


MAX_BYTES = 1024 ** 2
GST = timezone(timedelta(hours=4))


def now():
    return datetime.now(GST).strftime("%Y-%m-%d %H:%M:%S.%f GST")


def timeout_signal(signum, frame):
    raise TimeoutError("absolute HTTP deadline expired")


def serialized(body):
    if body is None:
        return b""
    if isinstance(body, bytes):
        return body
    return json.dumps(body, sort_keys=True, separators=(",", ":")).encode()


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


class Client:
    def __init__(self, host, evidence):
        if host != "opensearch":
            raise ValueError("only owned-network opensearch alias accepted")
        self.host = host
        self.evidence = Path(evidence)
        self.request_count = 0
        self.deadline = time.monotonic() + 180

    def start_suite_deadline(self):
        self.deadline = time.monotonic() + 600

    def request(self, name, method, path, body=None, statuses=(200,)):
        self.request_count += 1
        prefix = f"{self.request_count:04d}-{name}"
        data = serialized(body)
        if len(data) > MAX_BYTES:
            raise ValueError("request exceeds 1 MiB; not submitted")
        request_path = self.evidence / "requests" / f"{prefix}.body"
        request_path.parent.mkdir(parents=True, exist_ok=True)
        request_path.write_bytes(data)
        content_type = "application/x-ndjson" if isinstance(body, bytes) else "application/json"
        record = {"name": name, "argv": ["HTTP", method, "http://opensearch:9200" + path], "cwd": "/lab", "start_gst": now(), "timeout_seconds": 15, "request_artifact": str(request_path.relative_to(self.evidence)), "request_sha256": hashlib.sha256(data).hexdigest()}
        try:
            result = self.exchange(prefix, method, path, data, content_type, statuses)
        except Exception as error:
            record.update({"exit": 1, "error": f"{type(error).__name__}: {error}"})
            raise
        else:
            record["exit"] = 0
            return result
        finally:
            record["end_gst"] = now()
            self.append_command(record)

    def append_command(self, record):
        with (self.evidence / "commands.jsonl").open("a") as file:
            file.write(json.dumps(record, sort_keys=True) + "\n")

    def exchange(self, prefix, method, path, data, content_type, statuses):
        remaining = min(15, self.deadline - time.monotonic())
        if remaining <= 0:
            raise TimeoutError("full suite/readiness deadline expired")
        previous = signal.signal(signal.SIGALRM, timeout_signal)
        signal.setitimer(signal.ITIMER_REAL, remaining)
        connection = http.client.HTTPConnection(self.host, 9200, timeout=remaining)
        try:
            connection.request(method, path, body=data, headers={"Content-Type": content_type})
            response = connection.getresponse()
            return self.read_response(prefix, response, statuses)
        finally:
            connection.close()
            signal.setitimer(signal.ITIMER_REAL, 0)
            signal.signal(signal.SIGALRM, previous)

    def read_response(self, prefix, response, statuses):
        error = None
        try:
            raw = response.read(MAX_BYTES + 1)
            if response.length is None and not response.chunked and len(raw) <= MAX_BYTES:
                raw += response.read(1)
        except http.client.IncompleteRead as failure:
            raw = failure.partial
            error = failure
        return self.capture_response(prefix, response, raw, statuses, error)

    def capture_response(self, prefix, response, raw, statuses, read_error=None):
        directory = self.evidence / "responses"
        directory.mkdir(parents=True, exist_ok=True)
        complete = frame_complete(response, raw, read_error)
        headers = {"status": response.status, "headers": response.getheaders(), "body_bytes": len(raw), "bound_bytes": MAX_BYTES, "complete": complete, "remaining_content_length": response.length, "chunked": response.chunked, "read_error": None if read_error is None else f"{type(read_error).__name__}: {read_error}"}
        write_json(directory / f"{prefix}.headers.json", headers)
        if len(raw) > MAX_BYTES:
            (directory / f"{prefix}.oversized-prefix.partial").write_bytes(raw)
            raise ValueError("response exceeds 1 MiB; incomplete diagnostic prefix is not response evidence")
        if not complete:
            (directory / f"{prefix}.incomplete-frame.partial").write_bytes(raw)
            raise ValueError("HTTP message framing incomplete; partial diagnostic is not response evidence") from read_error
        (directory / f"{prefix}.json").write_bytes(raw)
        if response.status not in statuses:
            raise ValueError(f"unexpected HTTP {response.status}; full response retained")
        return json.loads(raw)


def frame_complete(response, raw, error):
    if error is not None or len(raw) > MAX_BYTES:
        return False
    if response.length is not None:
        return response.length == 0
    return response.isclosed()
