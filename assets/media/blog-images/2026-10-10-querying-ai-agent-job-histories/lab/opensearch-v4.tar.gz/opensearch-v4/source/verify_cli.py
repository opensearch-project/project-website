"""Independent checker process; invalid observations exit nonzero."""

import argparse
import json
import sys

import verifier as v


def check(args):
    actual = v.load(args.actual)
    expected = v.load(args.expected)
    handlers = {"Q01": check_q01, "history": check_history, "bulk": check_bulk, "redaction": check_redaction, "schema": check_schema}
    handlers[args.mode](actual, expected)


def check_q01(actual, expected):
    v.query01(actual, expected)


def check_history(actual, expected):
    v.history(actual, expected)


def check_bulk(actual, expected):
    v.bulk(actual, expected["ids"], expected["statuses"], expected["error_types"])


def check_redaction(actual, expected):
    v.redacted(actual, expected["markers"], expected["allowed"])


def check_schema(actual, expected):
    v.schema(actual)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=("Q01", "history", "bulk", "redaction", "schema"), required=True)
    parser.add_argument("--actual", required=True)
    parser.add_argument("--expected", required=True)
    args = parser.parse_args()
    try:
        check(args)
    except (AssertionError, ValueError, KeyError, TypeError) as error:
        print(json.dumps({"status": "REJECTED", "error": f"{type(error).__name__}: {error}"}))
        return 1
    print(json.dumps({"status": "ACCEPTED"}))
    return 0


if __name__ == "__main__":
    sys.exit(main())
