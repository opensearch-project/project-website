# Action-retry query checks

These literal authored expectations define the separate action-retry query checks. Observed results are supplied in the companion results files.

Separate index: <run-id>-os17-action-retry. Original main index, 33 events,
Q01-Q06, six compute-started buckets and OS01-16 remain unchanged.

Exact documents: fixture-expectations.json, in written producer order.
Submission IDs: s08, s07, s06, s05, s04, s03, s02, s01, with their literal
tenant/job/attempt prefixes. Eight create statuses 201; errors=false.
Mapping/settings and loader are identical to the original main corpus.
Explicit refresh: failed shards=0. Ingestion paused throughout pagination.

| Page | Incoming search_after | Sequences | Length |
| --- | --- | --- | ---: |
| 1 | omitted | 1,2,3 | 3 |
| 2 | [3,"alpha:job-action-retry:a1:s03"] | 4,5,6 | 3 |
| 3 | [6,"alpha:job-action-retry:a2:s06"] | 7,8 | 2 |
| 4 | [8,"alpha:job-action-retry:a2:s08"] | none | 0 |

Exactly four HTTP 200 complete JSON pages. Every page: timed_out=false,
hits.total={value:8,relation:eq}, shards={total:1,successful:1,skipped:0,failed:0}.
Each hit: exact concrete _index, _id=literal event_id, exact typed full _source,
sort=[integer sequence,string event_id]. Never sort observed data.
Next cursor is the actual previous last sort array, unchanged.

Interpretation: RECORDED_CONFIRMATION_BEFORE_RESTART. s05 confirmation precedes
s06 STARTED; s04/s05/s07 use alpha:job-action-retry:followup:v1. Attempt 1 has
no COMPLETED; attempt 2 has only s08 COMPLETED. Attempts [1,1,1,1,1,2,2,2].
Eight unique event IDs, two attempts, one action ID, three action-bearing rows.
No service receipt, effect count, tool/model call or actual restart is claimed.

Controls, each checker exit nonzero: s07 wrong action; all three wrong action;
remove s05 and repage with consistent seven totals/cursors; swap s05/s06;
swap sequence/sort values and reorder numerically; cut raw JSON; omit one hit;
omit terminal page; failed shard; total relation gte; wrong total; timed_out;
one copied executable/fixture/query/oracle binding hash changed.

Offline authored bundles exercise checker logic only. Later controls mutate
copies of genuine captures. Originals remain authoritative and unchanged.
Cleanup captures deletion and absence of the exact owned action-retry index before runtime teardown. The main corpus stays unchanged. Host prerequisites and resource guards remain enabled.
